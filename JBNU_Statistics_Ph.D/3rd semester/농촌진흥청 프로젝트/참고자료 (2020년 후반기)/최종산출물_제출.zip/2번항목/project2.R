## ----setup, include=FALSE--------------------------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----packages, ehco=FALSE,warning = FALSE, message = FALSE-----------------------------------------------
library(ggplot2) # ggplot을 활용한 시각화를 위한 package
library(gridExtra) # ggplot 여러개 동시에 보여주기 위한 package
library(mgcv) # GAM 을 위한 package
library(gvlma) # 오차항의 가정 검정을 위한 package
library(car) # 다중공선성 확인을 위한 vif 함수를 내장하고 있는 package
library(logistf) # Firth
library(segmented) # Local regression 을 위한 package
library(e1071) # svm을 위한 package
library(scatterplot3d) #3d plot을 그리기 위한 package
library(plotly) #ggplot 에 기반한 3d plot을 그리기 위한 package
library(ResourceSelection) #로지스틱모적 적합도 검정을 위한 package


## ----dataload--------------------------------------------------------------------------------------------
data<-read.csv("project2data.csv",check.names=FALSE)


## ----dataa-----------------------------------------------------------------------------------------------
dataa <- data[,c(1,6,7,8,9,10,11,12,15)]
colnames(dataa) <- c("엔진스피드","배기가스질량유량","배기가스온도","CO2배출량","CO배출량","NO배출량","NO2배출량","O2배출량","fuelrate")


## ----summary---------------------------------------------------------------------------------------------
summary(dataa)


## ----scatterplot,fig.height=10 , fig.width=10------------------------------------------------------------
plot(dataa)


## ----outlier---------------------------------------------------------------------------------------------
dataa <- dataa[-c(1218,1219,1220),]


## ----univariate1-----------------------------------------------------------------------------------------
g<-list() # ggplot 여러개를 동시에 보여주기 위해 list를 만들어서 저장하려고함. 그것을 위해 빈 list 를 미리 만듬
j=1       # 그래프 저장을 위한 초기값 1
r2 <-c() # 각 독립변수마다의 r2를 for을 통해 저장하려고 하는데 그전에 저장할 빈 vector를 만듬
coef <- matrix(nrow=3,ncol=4) # model 결과들에 대한 값들을 집어넣기위해 빈 matrix 생성
for(i in 1:3){
  y <- dataa[,9] # 종속변수 지정 
  x <- dataa[,i] # 독립변수 지정
  df <-data.frame(x,y) # lm 을 위해 독립변수와 종속변수를 합쳐서 data frame 으로 만듬
  xnam <- colnames(dataa)[i] # 그래프의 x축 이름을 각 독립변수로 자동 지정
  ynam <- colnames(dataa)[9] # 그래프의 y축 이름 고정 지정
  ly <- lm(y~x) # simple linear model
  r2[j] <- summary(ly)$adj.r.squared # 각 linear model의 r square
  coef[j,] <- summary(ly)$coefficients[2,] # 각 모델들의 계수, std error , t value , p value
  g[[j]]<-ggplot(df,aes(x,y))+        # ggplot 을 통한 시각화 xlab : x 축 이름. 미리 지정해놓은 xnam 활용
    xlab(xnam)+ylab(ynam)+            # ylab : y 축 이름. 미리 지정해놓은 ynam 활용
    geom_point()+                     # 점을 찍음
    geom_smooth(method="lm")          # linear model의 추정선을 그림
  j=j+1                               # 그래프 저장을 위한 것
}
colnames(coef)<-c("Coefficient","Std.Error","t value","Pvalue")  # 모델 결과들이 어떤건지 알려주기위해 열이름 지정


data.frame(Univariate=colnames(dataa)[1:3],r2=r2,coef) # 위의 결과를 data frame 으로 만들어서 확인
grid.arrange(g[[1]],g[[2]],g[[3]],nrow=2,ncol=2) # ggplot


## ----vif11-----------------------------------------------------------------------------------------------
vif(lm(fuelrate~엔진스피드+배기가스질량유량+배기가스온도,dataa))


## ----vif12-----------------------------------------------------------------------------------------------
vif(lm(fuelrate~배기가스질량유량+배기가스온도,dataa))


## ----lm1-------------------------------------------------------------------------------------------------
lmod <- lm(fuelrate ~ 배기가스질량유량+배기가스온도,data=dataa)
summary(lmod)


## ----residualplot1---------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod),residuals(lmod),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck1--------------------------------------------------------------------------------------
gvlma(lmod)


## ----lm1in-----------------------------------------------------------------------------------------------
lmod <-lm(fuelrate~배기가스질량유량+배기가스온도+배기가스질량유량:배기가스온도,dataa)
summary(lmod)


## ----residualplot1in-------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod),residuals(lmod),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck1in------------------------------------------------------------------------------------
gvlma(lmod)


## ----concurforgasf---------------------------------------------------------------------------------------
model <- gam(fuelrate ~ s(배기가스질량유량)+s(엔진스피드)+s(배기가스온도),data=dataa)
concurvity(model,full=T)


## ----concurforgasf2--------------------------------------------------------------------------------------
model <- gam(fuelrate ~ s(엔진스피드)+s(배기가스온도),data=dataa)
concurvity(model,full=T)


## ----gam1------------------------------------------------------------------------------------------------
model <- gam(fuelrate~s(엔진스피드),data=dataa)
summary(model)


## ----gamplot1--------------------------------------------------------------------------------------------
plot(model,page=1)


## ----seg-------------------------------------------------------------------------------------------------
lmod <-lm(fuelrate~엔진스피드,dataa)
o <- segmented(lmod);o


## ----redfuelrate-----------------------------------------------------------------------------------------
a<-subset(dataa,dataa$엔진스피드>2000)
ggplot(dataa)+
  geom_point(mapping=aes(x=배기가스질량유량,y=fuelrate))+
  geom_point(mapping=aes(x=배기가스질량유량,y=fuelrate),data=a,col='red')

ggplot(dataa)+
  geom_point(mapping=aes(x=배기가스온도,y=fuelrate))+
  geom_point(mapping=aes(x=배기가스온도,y=fuelrate),data=a,col='red')


## ----locallinearfuelrate---------------------------------------------------------------------------------
lhs <- function(x) ifelse(x < 2000,2000-x,0)
rhs <- function(x) ifelse(x < 2000,0,x-2000)
lmod1 <- lm(fuelrate ~ 배기가스온도+배기가스질량유량+lhs(엔진스피드) + rhs(엔진스피드), dataa)
summary(lmod1)


## ----ggplotpiecewisefitfuelrate--------------------------------------------------------------------------
g <-list()
g[[1]]<-ggplot(dataa)+
  geom_point(mapping=aes(x=엔진스피드,y=fuelrate))+
  geom_point(mapping=aes(x=엔진스피드,y=lmod1$fitted.values),col='blue')

g[[2]]<-ggplot(dataa)+
  geom_point(mapping=aes(x=배기가스질량유량,y=fuelrate))+
  geom_point(mapping=aes(x=배기가스질량유량,y=lmod1$fitted.values),col='blue')

g[[3]]<-ggplot(dataa)+
  geom_point(mapping=aes(x=배기가스온도,y=fuelrate))+
  geom_point(mapping=aes(x=배기가스온도,y=lmod1$fitted.values),col='blue')
grid.arrange(g[[1]],g[[2]],g[[3]],nrow=2,ncol=2)


## ----residualplot1piecefuel------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod1),residuals(lmod1),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod1),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod1),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck1piecefuel-----------------------------------------------------------------------------
gvlma(lmod1)


## ----localsimplelinearfuelrate---------------------------------------------------------------------------
lmod2 <- lm(fuelrate ~ lhs(엔진스피드) + rhs(엔진스피드), dataa)
summary(lmod2)


## ----ggplotsimplepiecewisefitfuelrate--------------------------------------------------------------------
ggplot(dataa)+
  geom_point(mapping=aes(x=엔진스피드,y=fuelrate))+
  geom_point(mapping=aes(x=엔진스피드,y=lmod2$fitted.values),col='blue')


## ----residualplot2piecefuel------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod2),residuals(lmod2),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod2),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod2),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck2piecefuel-----------------------------------------------------------------------------
gvlma(lmod2)


## ----boostrap fuelrate-----------------------------------------------------------------------------------
betahat = lmod2$coefficients

B=1000   # 붓스트랩 반복수
N=nrow(dataa)  # 데이터 사이즈 
betaast=matrix(NA,B,length(lmod2$coefficients)) # 붓스트랩 통계량 행렬
set.seed(1)  
IND=matrix(sample(1:N,B*N,replace=T),B,N)   # 붓스트랩 표본추출

for (i in 1:B)
{
  data_ast = dataa[IND[i,],]    # i번째 붓스트랩 표본
  lmod_temp = lm(fuelrate ~ lhs(엔진스피드) + rhs(엔진스피드), data_ast) # 붓스트랩 표본 모형적합
  betaast[i,]=lmod_temp$coefficients  # i번째 붓스트랩 통계량
}

quant_ast = apply(betaast,2,quantile,probs=c(0.025,0.975))  # 붓스트랩 통계량의 분위수
CI_lhs = rbind(2*betahat[2]-quant_ast[2:1,2],quant_ast[,2])    # lhs에 대한 95% 신뢰구간
rownames(CI_lhs) = c("pivotal","percentile")
CI_rhs = rbind(2*betahat[3]-quant_ast[2:1,3],quant_ast[,3])    # rhs에 대한 95% 신뢰구간
rownames(CI_rhs) = c("pivotal","percentile")
CI_lhs # lhs에 대한 95% 신뢰구간
CI_rhs # rhs에 대한 95% 신뢰구간


## ----univariate2-----------------------------------------------------------------------------------------
g<-list() # ggplot 여러개를 동시에 보여주기 위해 list를 만들어서 저장하려고함. 그것을 위해 빈 list 를 미리 만듬
j=1       # 그래프 저장을 위한 초기값 1
r2 <-c() # 각 독립변수마다의 r2를 for을 통해 저장하려고 하는데 그전에 저장할 빈 vector를 만듬
coef <- matrix(nrow=3,ncol=4) # model 결과들에 대한 값들을 집어넣기위해 빈 matrix 생성
for(i in c(1,3,9)){
  y <- dataa[,2] # 종속변수 지정 
  x <- dataa[,i] # 독립변수 지정
  df <-data.frame(x,y) # lm 을 위해 독립변수와 종속변수를 합쳐서 data frame 으로 만듬
  xnam <- colnames(dataa)[i] # 그래프의 x축 이름을 각 독립변수로 자동 지정
  ynam <- colnames(dataa)[2] # 그래프의 y축 이름 고정 지정
  ly <- lm(y~x) # simple linear model
  r2[j] <- summary(ly)$adj.r.squared # 각 linear model의 r square
  coef[j,] <- summary(ly)$coefficients[2,] # 각 모델들의 계수, std error , t value , p value
  g[[j]]<-ggplot(df,aes(x,y))+        # ggplot 을 통한 시각화 xlab : x 축 이름. 미리 지정해놓은 xnam 활용
    xlab(xnam)+ylab(ynam)+            # ylab : y 축 이름. 미리 지정해놓은 ynam 활용
    geom_point()+                     # 점을 찍음
    geom_smooth(method="lm")          # linear model의 추정선을 그림
  j=j+1                               # 그래프 저장을 위한 것
}
colnames(coef)<-c("Coefficient","Std.Error","t value","Pvalue")  # 모델 결과들이 어떤건지 알려주기위해 열이름 지정


data.frame(Univariate=colnames(dataa)[c(1,3,9)],r2=r2,coef) # 위의 결과를 data frame 으로 만들어서 확인
grid.arrange(g[[1]],g[[2]],g[[3]],nrow=2,ncol=2) # ggplot


## ----vif21-----------------------------------------------------------------------------------------------
vif(lm(배기가스질량유량~엔진스피드+fuelrate+배기가스온도,dataa))


## ----vif22-----------------------------------------------------------------------------------------------
vif(lm(배기가스질량유량~엔진스피드+배기가스온도,dataa))


## ----lm2-------------------------------------------------------------------------------------------------
lmod <- lm(배기가스질량유량~엔진스피드+배기가스온도,dataa)
summary(lmod)


## ----residualplot2---------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod),residuals(lmod),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck2--------------------------------------------------------------------------------------
gvlma(lmod)


## ----lm2in-----------------------------------------------------------------------------------------------
lmod <-lm(배기가스질량유량~엔진스피드+배기가스온도+엔진스피드:배기가스온도,dataa)
summary(lmod)


## ----residualplot2in-------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod),residuals(lmod),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck2in------------------------------------------------------------------------------------
gvlma(lmod)


## ----concurforgas----------------------------------------------------------------------------------------
model <- gam(배기가스질량유량~s(엔진스피드)+s(fuelrate)+s(배기가스온도),data=dataa)
concurvity(model,full=T)


## ----concurforgas2---------------------------------------------------------------------------------------
model <- gam(배기가스질량유량~s(엔진스피드)+s(배기가스온도),data=dataa)
concurvity(model,full=T)


## ----gam2------------------------------------------------------------------------------------------------
model <- gam(배기가스질량유량~s(엔진스피드),data=dataa)
summary(model)


## ----gamplot2--------------------------------------------------------------------------------------------
plot(model,page=1)


## ----lmmlllmlmmmm----------------------------------------------------------------------------------------
lmod<-lm(배기가스질량유량~엔진스피드,data=dataa)
summary(lm(배기가스질량유량~엔진스피드,data=dataa))


## ----residualgas-----------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod),residuals(lmod),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualgas2----------------------------------------------------------------------------------------
gvlma(lmod)


## ----bootstrap gas---------------------------------------------------------------------------------------
betahat = lmod$coefficients

B=1000   # 붓스트랩 반복수
N=nrow(dataa)  # 데이터 사이즈 
betaast=matrix(NA,B,length(lmod$coefficients)) # 붓스트랩 통계량 행렬
set.seed(1)  
IND=matrix(sample(1:N,B*N,replace=T),B,N)   # 붓스트랩 표본추출

for (i in 1:B)
{
  data_ast = dataa[IND[i,],]    # i번째 붓스트랩 표본
  lmod_temp = lm(배기가스질량유량~엔진스피드,data_ast) # 붓스트랩 표본 모형적합
  betaast[i,]=lmod_temp$coefficients  # i번째 붓스트랩 통계량
}

quant_ast = apply(betaast,2,quantile,probs=c(0.025,0.975))  # 붓스트랩 통계량의 분위수
CI = rbind(2*betahat[2]-quant_ast[2:1,2],quant_ast[,2])    # 계수에 대한 95% 신뢰구간
rownames(CI) = c("pivotal","percentile")
CI


## ----univariate3-----------------------------------------------------------------------------------------
g<-list() # ggplot 여러개를 동시에 보여주기 위해 list를 만들어서 저장하려고함. 그것을 위해 빈 list 를 미리 만듬
j=1       # 그래프 저장을 위한 초기값 1
r2 <-c() # 각 독립변수마다의 r2를 for을 통해 저장하려고 하는데 그전에 저장할 빈 vector를 만듬
coef <- matrix(nrow=2,ncol=4) # model 결과들에 대한 값들을 집어넣기위해 빈 matrix 생성
for(i in c(1,3)){
  y <- dataa[,4] # 종속변수 지정 
  x <- dataa[,i] # 독립변수 지정
  df <-data.frame(x,y) # lm 을 위해 독립변수와 종속변수를 합쳐서 data frame 으로 만듬
  xnam <- colnames(dataa)[i] # 그래프의 x축 이름을 각 독립변수로 자동 지정
  ynam <- colnames(dataa)[4] # 그래프의 y축 이름 고정 지정
  ly <- lm(y~x) # simple linear model
  r2[j] <- summary(ly)$adj.r.squared # 각 linear model의 r square
  coef[j,] <- summary(ly)$coefficients[2,] # 각 모델들의 계수, std error , t value , p value
  g[[j]]<-ggplot(df,aes(x,y))+        # ggplot 을 통한 시각화 xlab : x 축 이름. 미리 지정해놓은 xnam 활용
    xlab(xnam)+ylab(ynam)+            # ylab : y 축 이름. 미리 지정해놓은 ynam 활용
    geom_point()+                     # 점을 찍음
    geom_smooth(method="lm")          # linear model의 추정선을 그림
  j=j+1                               # 그래프 저장을 위한 것
}
colnames(coef)<-c("Coefficient","Std.Error","t value","Pvalue")  # 모델 결과들이 어떤건지 알려주기위해 열이름 지정


data.frame(Univariate=colnames(dataa)[c(1,3)],r2=r2,coef) # 위의 결과를 data frame 으로 만들어서 확인
grid.arrange(g[[1]],g[[2]],nrow=1,ncol=2) # ggplot


## ----plotlyscatter3dco2,warning = FALSE, message = FALSE-------------------------------------------------
plot_ly(x=dataa$엔진스피드,y=dataa$배기가스온도,z = dataa$CO2배출량, type = "scatter3d", mode="markers")


## ----plotlyco2-------------------------------------------------------------------------------------------
p <- plot_ly(dataa, x = ~엔진스피드, y = ~배기가스온도)
add_markers(p, color = ~CO2배출량)


## ----vif31-----------------------------------------------------------------------------------------------
vif(lm(CO2배출량 ~ 엔진스피드+배기가스온도,data=dataa))


## ----lm3-------------------------------------------------------------------------------------------------
lmod <- lm(CO2배출량 ~ 엔진스피드+배기가스온도,data=dataa)
summary(lmod)


## ----residualplot3---------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod),residuals(lmod),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck3--------------------------------------------------------------------------------------
gvlma(lmod)


## ----lm3in-----------------------------------------------------------------------------------------------
lmod <-lm(CO2배출량 ~ 엔진스피드+배기가스온도+엔진스피드:배기가스온도,data=dataa)
summary(lmod)


## ----residualplot3in-------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod),residuals(lmod),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck3in------------------------------------------------------------------------------------
gvlma(lmod)


## ----concurforco2----------------------------------------------------------------------------------------
model <- gam(CO2배출량 ~ s(엔진스피드)+s(배기가스온도),data=dataa)
concurvity(model,full=T)


## ----gamsummary3-----------------------------------------------------------------------------------------
summary(model)


## ----gamplot3--------------------------------------------------------------------------------------------
plot(model,page=1)


## ----intergam--------------------------------------------------------------------------------------------
model <- gam(CO2배출량 ~ s(엔진스피드)+s(배기가스온도)+ti(엔진스피드,배기가스온도),data=dataa)
summary(model)


## ----gamplot3in,fig.height=10 , fig.width=10-------------------------------------------------------------
plot(model,page=1)


## ----visgamcontourco2------------------------------------------------------------------------------------
vis.gam(model,plot.type="contour", too.far=0.1)



## ----seg2co2---------------------------------------------------------------------------------------------
lmod <-lm(CO2배출량~엔진스피드+배기가스온도,dataa)
o <- segmented(lmod,seg.Z=~엔진스피드);o


## ----plot2000co2-----------------------------------------------------------------------------------------
a<-subset(dataa,dataa$엔진스피드>1999)
ggplot(dataa)+
  geom_point(mapping=aes(x=배기가스온도,y=CO2배출량))+
  geom_point(mapping=aes(x=배기가스온도,y=CO2배출량),data=a,col='red')


## ----locallinearco2--------------------------------------------------------------------------------------
lhs <- function(x) ifelse(x < 1999,1999-x,0)
rhs <- function(x) ifelse(x < 1999,0,x-1999)
lmod1 <- lm(CO2배출량 ~ 배기가스온도+lhs(엔진스피드) + rhs(엔진스피드), dataa)
summary(lmod1)


## ----plotlylocalco2,warning = FALSE, message = FALSE-----------------------------------------------------
subplot(
plot_ly(x=dataa$엔진스피드, y=dataa$배기가스온도, z=lmod1$fitted.values, type="scatter3d", mode="markers")
,plot_ly(x=dataa$엔진스피드, y=dataa$배기가스온도, z=dataa$CO2배출량, type="scatter3d", mode="markers",color=I("red"))
)


## ----residualplot1piececo2-------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod1),residuals(lmod1),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod1),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod1),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck1piececo2------------------------------------------------------------------------------
gvlma(lmod1)


## ----locallinearinterco2---------------------------------------------------------------------------------
lhs <- function(x) ifelse(x < 1999,1999-x,0)
rhs <- function(x) ifelse(x < 1999,0,x-1999)
lmod2 <- lm(CO2배출량 ~ 배기가스온도+lhs(엔진스피드) + rhs(엔진스피드)+배기가스온도:lhs(엔진스피드)+배기가스온도:rhs(엔진스피드), dataa)
summary(lmod2)


## ----data12co2-------------------------------------------------------------------------------------------
dataa1 <- dataa[dataa$엔진스피드<o$psi[2],]
dataa2 <- dataa[dataa$엔진스피드>=o$psi[2],]

## ----localgam1co2----------------------------------------------------------------------------------------
gam1 <- gam(CO2배출량 ~ s(엔진스피드)+s(배기가스온도),data = dataa1)
summary(gam1)


## ----localgam2co2----------------------------------------------------------------------------------------
gam2 <- gam(CO2배출량 ~ s(엔진스피드)+s(배기가스온도),data = dataa2)
summary(gam2)


## ----localgamplotco2-------------------------------------------------------------------------------------
par(mfrow=c(2,2))
plot(gam1)
plot(gam2)


## ----locallinearco2simple--------------------------------------------------------------------------------
lmod3 <- lm(CO2배출량 ~ lhs(엔진스피드) + rhs(엔진스피드), dataa)
summary(lmod3)


## ----plotlylocalco2simple,warning = FALSE, message = FALSE-----------------------------------------------
subplot(
plot_ly(x=dataa$엔진스피드, y=dataa$배기가스온도, z=lmod3$fitted.values, type="scatter3d", mode="markers")
,plot_ly(x=dataa$엔진스피드, y=dataa$배기가스온도, z=dataa$CO2배출량, type="scatter3d", mode="markers",color=I("red"))
)


## ----residualplot1piececo2simple-------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod3),residuals(lmod3),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod3),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod3),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck1piececo2simple------------------------------------------------------------------------
gvlma(lmod3)


## ----boostrap CO2----------------------------------------------------------------------------------------
betahat = lmod3$coefficients

B=1000   # 붓스트랩 반복수
N=nrow(dataa)  # 데이터 사이즈 
betaast=matrix(NA,B,length(lmod3$coefficients)) # 붓스트랩 통계량 행렬

for (i in 1:B)
{
  data_ast = dataa[IND[i,],]    # i번째 붓스트랩 표본
  lmod_temp = lm(CO2배출량 ~ lhs(엔진스피드) + rhs(엔진스피드), data_ast) # 붓스트랩 표본 모형적합
  betaast[i,]=lmod_temp$coefficients  # i번째 붓스트랩 통계량
}

quant_ast = apply(betaast,2,quantile,probs=c(0.025,0.975))  # 붓스트랩 통계량의 분위수
CI_lhs = rbind(2*betahat[2]-quant_ast[2:1,2],quant_ast[,2])    # lhs에 대한 95% 신뢰구간
rownames(CI_lhs) = c("pivotal","percentile")
CI_rhs = rbind(2*betahat[3]-quant_ast[2:1,3],quant_ast[,3])    # rhs에 대한 95% 신뢰구간
rownames(CI_rhs) = c("pivotal","percentile")
CI_lhs # lhs에 대한 95% 신뢰구간
CI_rhs # rhs에 대한 95% 신뢰구간


## ----univariate4-----------------------------------------------------------------------------------------
g<-list() # ggplot 여러개를 동시에 보여주기 위해 list를 만들어서 저장하려고함. 그것을 위해 빈 list 를 미리 만듬
j=1       # 그래프 저장을 위한 초기값 1
r2 <-c() # 각 독립변수마다의 r2를 for을 통해 저장하려고 하는데 그전에 저장할 빈 vector를 만듬
coef <- matrix(nrow=2,ncol=4) # model 결과들에 대한 값들을 집어넣기위해 빈 matrix 생성
for(i in c(1,3)){
  y <- dataa[,5] # 종속변수 지정 
  x <- dataa[,i] # 독립변수 지정
  df <-data.frame(x,y) # lm 을 위해 독립변수와 종속변수를 합쳐서 data frame 으로 만듬
  xnam <- colnames(dataa)[i] # 그래프의 x축 이름을 각 독립변수로 자동 지정
  ynam <- colnames(dataa)[5] # 그래프의 y축 이름 고정 지정
  ly <- lm(y~x) # simple linear model
  r2[j] <- summary(ly)$adj.r.squared # 각 linear model의 r square
  coef[j,] <- summary(ly)$coefficients[2,] # 각 모델들의 계수, std error , t value , p value
  g[[j]]<-ggplot(df,aes(x,y))+        # ggplot 을 통한 시각화 xlab : x 축 이름. 미리 지정해놓은 xnam 활용
    xlab(xnam)+ylab(ynam)+            # ylab : y 축 이름. 미리 지정해놓은 ynam 활용
    geom_point()+                     # 점을 찍음
    geom_smooth(method="lm")          # linear model의 추정선을 그림
  j=j+1                               # 그래프 저장을 위한 것
}
colnames(coef)<-c("Coefficient","Std.Error","t value","Pvalue")  # 모델 결과들이 어떤건지 알려주기위해 열이름 지정


data.frame(Univariate=colnames(dataa)[c(1,3)],r2=r2,coef) # 위의 결과를 data frame 으로 만들어서 확인
grid.arrange(g[[1]],g[[2]],nrow=1,ncol=2) # ggplot


## ----vif41-----------------------------------------------------------------------------------------------
vif(lm(CO배출량 ~ 엔진스피드+배기가스온도,data=dataa))


## ----lm4-------------------------------------------------------------------------------------------------
lmod <- lm(CO배출량 ~ 엔진스피드+배기가스온도,data=dataa)
summary(lmod)


## ----lm4in-----------------------------------------------------------------------------------------------
lmod <-lm(CO배출량 ~ 엔진스피드*배기가스온도,data=dataa)
summary(lmod)


## ----gam4------------------------------------------------------------------------------------------------
model <- gam(CO배출량 ~ s(엔진스피드)+s(배기가스온도),data=dataa)
summary(model)


## ----gamplot4--------------------------------------------------------------------------------------------
plot(model,page=1)


## ----glmvif1---------------------------------------------------------------------------------------------
y <- dataa$'CO배출량'
y[y>0]<-1
x <- dataa[,c(1,3)]
daf <- cbind(x,y)
vif(glm(y~.,data=daf,family=binomial))


## ----glm-------------------------------------------------------------------------------------------------
model<-glm(y~배기가스온도+엔진스피드,data=daf,family=binomial)
summary(model)
hoslem.test(daf$y,fitted(model)) # 로지스틱 유의성 검정


## ----glm2------------------------------------------------------------------------------------------------
model<-glm(y~배기가스온도*엔진스피드,data=daf,family=binomial)
summary(model)


## ----firth-----------------------------------------------------------------------------------------------
model<-logistf(y~.,data=daf,family=binomial)
summary(model)


## ----svmco-----------------------------------------------------------------------------------------------
dataa$CO <- as.factor(ifelse(dataa$CO배출량>0,1,0))
dat <- dataa[,c("CO","배기가스온도","엔진스피드")]
svmfit=svm(CO ~., data=dat)
plot(svmfit,dat) # support vectors are crosses 


## ----svmtable--------------------------------------------------------------------------------------------
table(svmfit$fitted,dat$CO)


## ----univariate5-----------------------------------------------------------------------------------------
g<-list() # ggplot 여러개를 동시에 보여주기 위해 list를 만들어서 저장하려고함. 그것을 위해 빈 list 를 미리 만듬
j=1       # 그래프 저장을 위한 초기값 1
r2 <-c() # 각 독립변수마다의 r2를 for을 통해 저장하려고 하는데 그전에 저장할 빈 vector를 만듬
coef <- matrix(nrow=2,ncol=4) # model 결과들에 대한 값들을 집어넣기위해 빈 matrix 생성
for(i in c(1,3)){
  y <- dataa[,6] # 종속변수 지정 
  x <- dataa[,i] # 독립변수 지정
  df <-data.frame(x,y) # lm 을 위해 독립변수와 종속변수를 합쳐서 data frame 으로 만듬
  xnam <- colnames(dataa)[i] # 그래프의 x축 이름을 각 독립변수로 자동 지정
  ynam <- colnames(dataa)[6] # 그래프의 y축 이름 고정 지정
  ly <- lm(y~x) # simple linear model
  r2[j] <- summary(ly)$adj.r.squared # 각 linear model의 r square
  coef[j,] <- summary(ly)$coefficients[2,] # 각 모델들의 계수, std error , t value , p value
  g[[j]]<-ggplot(df,aes(x,y))+        # ggplot 을 통한 시각화 xlab : x 축 이름. 미리 지정해놓은 xnam 활용
    xlab(xnam)+ylab(ynam)+            # ylab : y 축 이름. 미리 지정해놓은 ynam 활용
    geom_point()+                     # 점을 찍음
    geom_smooth(method="lm")          # linear model의 추정선을 그림
  j=j+1                               # 그래프 저장을 위한 것
}
colnames(coef)<-c("Coefficient","Std.Error","t value","Pvalue")  # 모델 결과들이 어떤건지 알려주기위해 열이름 지정


data.frame(Univariate=colnames(dataa)[c(1,3)],r2=r2,coef) # 위의 결과를 data frame 으로 만들어서 확인
grid.arrange(g[[1]],g[[2]],nrow=1,ncol=2) # ggplot


## ----plotlyscatter5dno,warning = FALSE, message = FALSE--------------------------------------------------
plot_ly(x=dataa$엔진스피드,y=dataa$배기가스온도,z = dataa$NO배출량, type = "scatter3d", mode="markers")


## ----plotlyno--------------------------------------------------------------------------------------------
p <- plot_ly(dataa, x = ~엔진스피드, y = ~배기가스온도)
add_markers(p, color = ~NO배출량)


## ----changecutno-----------------------------------------------------------------------------------------
lmod <-lm(NO배출량~ 엔진스피드 ,dataa)
o <- segmented(lmod,seg.Z=~엔진스피드,npsi = 2);o


## ----databno---------------------------------------------------------------------------------------------
datab <- subset(dataa,엔진스피드<2186)


## ----plotlyscatter3d2no,warning = FALSE, message = FALSE-------------------------------------------------
plot_ly(x=datab$엔진스피드,y=datab$배기가스온도,z = datab$NO배출량, type = "scatter3d", mode="markers")


## ----plotly2no-------------------------------------------------------------------------------------------
p <- plot_ly(datab, x = ~엔진스피드, y = ~배기가스온도)
add_markers(p, color = ~NO배출량)


## ----vif51-----------------------------------------------------------------------------------------------
vif(lm(NO배출량 ~ 엔진스피드+배기가스온도,data=datab))


## ----lm5-------------------------------------------------------------------------------------------------
lmod <- lm(NO배출량 ~ 엔진스피드+배기가스온도,data=datab)
summary(lmod)


## ----residualplot5---------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod),residuals(lmod),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck5--------------------------------------------------------------------------------------
gvlma(lmod)


## ----lm5in-----------------------------------------------------------------------------------------------
lmod <-lm(NO배출량 ~ 엔진스피드+배기가스온도+엔진스피드:배기가스온도,data=datab)
summary(lmod)


## ----residualplot5in-------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod),residuals(lmod),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck5in------------------------------------------------------------------------------------
gvlma(lmod)


## ----concurforno-----------------------------------------------------------------------------------------
model <- gam(NO배출량 ~ s(엔진스피드)+s(배기가스온도),data=datab)
concurvity(model,full=T)


## ----gamsummary5-----------------------------------------------------------------------------------------
summary(model)


## ----gamplot5--------------------------------------------------------------------------------------------
plot(model,page=1)


## ----intergamno------------------------------------------------------------------------------------------
model <- gam(NO배출량 ~ s(엔진스피드)+s(배기가스온도)+ti(엔진스피드,배기가스온도),data=datab)
summary(model)


## ----gamplot5in,fig.height=10 , fig.width=10-------------------------------------------------------------
plot(model,page=1)


## ----visgamcontourno-------------------------------------------------------------------------------------
vis.gam(model,plot.type="contour", too.far=0.1)



## ----seg2no----------------------------------------------------------------------------------------------
lmod <-lm(NO배출량~엔진스피드,datab)
o <- segmented(lmod,seg.Z=~엔진스피드);o


## ----plot2074--------------------------------------------------------------------------------------------
a<-subset(datab,datab$엔진스피드>2134)
ggplot(datab)+
  geom_point(mapping=aes(x=배기가스온도,y=NO배출량))+
  geom_point(mapping=aes(x=배기가스온도,y=NO배출량),data=a,col='red')


## ----locallinearno---------------------------------------------------------------------------------------
lhs <- function(x) ifelse(x < 2134,2134-x,0)
rhs <- function(x) ifelse(x < 2134,0,x-2134)
lmod1 <- lm(NO배출량 ~ 배기가스온도+lhs(엔진스피드) + rhs(엔진스피드), datab)
summary(lmod1)


## ----plotlylocalno,warning = FALSE, message = FALSE------------------------------------------------------
subplot(
  plot_ly(x=datab$엔진스피드, y=datab$배기가스온도, z=lmod1$fitted.values, type="scatter3d", mode="markers")
  ,plot_ly(x=datab$엔진스피드, y=datab$배기가스온도, z=datab$NO배출량, type="scatter3d", mode="markers",color=I("red"))
)


## ----residualplot1pieceno11------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod1),residuals(lmod1),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod1),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod1),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck1pieceno111----------------------------------------------------------------------------
gvlma(lmod1)


## ----no bootsrap-----------------------------------------------------------------------------------------
betahat = lmod1$coefficients

B=1000   # 붓스트랩 반복수
N=nrow(datab)  # 데이터 사이즈 
betaast=matrix(NA,B,length(lmod1$coefficients)) # 붓스트랩 통계량 행렬
set.seed(1)  
IND=matrix(sample(1:N,B*N,replace=T),B,N)   # 붓스트랩 표본추출

for (i in 1:B)
{
  data_ast = datab[IND[i,],]    # i번째 붓스트랩 표본
  lmod_temp = lm(NO배출량 ~ 배기가스온도+lhs(엔진스피드) + rhs(엔진스피드), data_ast) # 붓스트랩 표본 모형적합
  betaast[i,]=lmod_temp$coefficients  # i번째 붓스트랩 통계량
}

quant_ast = apply(betaast,2,quantile,probs=c(0.025,0.975))  # 붓스트랩 통계량의 분위수
temp = rbind(2*betahat[2]-quant_ast[2:1,2],quant_ast[,2])    # 온도에 대한 95% 신뢰구간
rownames(temp) = c("pivotal","percentile")
CI_lhs = rbind(2*betahat[3]-quant_ast[2:1,3],quant_ast[,3])    # lhs에 대한 95% 신뢰구간
rownames(CI_lhs) = c("pivotal","percentile")
CI_rhs = rbind(2*betahat[4]-quant_ast[2:1,4],quant_ast[,4])    # rhs에 대한 95% 신뢰구간
rownames(CI_rhs) = c("pivotal","percentile")
temp # 온도에 대한 95% 신뢰구간
CI_lhs # lhs에 대한 95% 신뢰구간
CI_rhs # rhs에 대한 95% 신뢰구간


## ----locallinearinterno----------------------------------------------------------------------------------
lmod2 <- lm(NO배출량 ~ 배기가스온도+lhs(엔진스피드) + rhs(엔진스피드)+배기가스온도:lhs(엔진스피드)+배기가스온도:rhs(엔진스피드), datab)
summary(lmod2)


## ----plotlylocal2no,warning = FALSE, message = FALSE-----------------------------------------------------
subplot(
  plot_ly(x=datab$엔진스피드, y=datab$배기가스온도, z=lmod2$fitted.values, type="scatter3d", mode="markers")
  ,plot_ly(x=datab$엔진스피드, y=datab$배기가스온도, z=datab$NO배출량, type="scatter3d", mode="markers",color=I("red"))
)


## ----residualplot1pieceno--------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod2),residuals(lmod2),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod2),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod2),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck1pieceno-------------------------------------------------------------------------------
gvlma(lmod2)


## ----no bootsrap2----------------------------------------------------------------------------------------
betahat = lmod2$coefficients

B=1000   # 붓스트랩 반복수
N=nrow(datab)  # 데이터 사이즈 
betaast=matrix(NA,B,length(lmod2$coefficients)) # 붓스트랩 통계량 행렬
set.seed(1)  
IND=matrix(sample(1:N,B*N,replace=T),B,N)   # 붓스트랩 표본추출

for (i in 1:B)
{
  data_ast = datab[IND[i,],]    # i번째 붓스트랩 표본
  lmod_temp = lm(NO배출량 ~ 배기가스온도+lhs(엔진스피드) + rhs(엔진스피드)+배기가스온도:lhs(엔진스피드)+배기가스온도:rhs(엔진스피드), data_ast) # 붓스트랩 표본 모형적합
  betaast[i,]=lmod_temp$coefficients  # i번째 붓스트랩 통계량
}

quant_ast = apply(betaast,2,quantile,probs=c(0.025,0.975))  # 붓스트랩 통계량의 분위수
temp = rbind(2*betahat[2]-quant_ast[2:1,2],quant_ast[,2])    # 온도에 대한 95% 신뢰구간
rownames(temp) = c("pivotal","percentile")
CI_lhs = rbind(2*betahat[3]-quant_ast[2:1,3],quant_ast[,3])    # lhs에 대한 95% 신뢰구간
rownames(CI_lhs) = c("pivotal","percentile")
CI_rhs = rbind(2*betahat[4]-quant_ast[2:1,4],quant_ast[,4])    # rhs에 대한 95% 신뢰구간
rownames(CI_rhs) = c("pivotal","percentile")
CI_lhsTemp = rbind(2*betahat[5]-quant_ast[2:1,5],quant_ast[,5])    # lhs와 온도의 교호작용항에 대한 95% 신뢰구간
rownames(CI_lhsTemp) = c("pivotal","percentile")
CI_rhsTemp = rbind(2*betahat[6]-quant_ast[2:1,6],quant_ast[,6])    # rhs와 온도의 교호작용항에 대한 95% 신뢰구간
rownames(CI_rhsTemp) = c("pivotal","percentile")

temp # 온도에 대한 95% 신뢰구간
CI_lhs # lhs에 대한 95% 신뢰구간
CI_rhs # rhs에 대한 95% 신뢰구간







CI_lhsTemp # lhs와 온도의 교호작용항에 대한 95% 신뢰구간
CI_rhsTemp # rhs와 온도의 교호작용항에 대한 95% 신뢰구간


## ----anovano---------------------------------------------------------------------------------------------
anova(lmod1,lmod2)


## ----univariate6-----------------------------------------------------------------------------------------
g<-list() # ggplot 여러개를 동시에 보여주기 위해 list를 만들어서 저장하려고함. 그것을 위해 빈 list 를 미리 만듬
j=1       # 그래프 저장을 위한 초기값 1
r2 <-c() # 각 독립변수마다의 r2를 for을 통해 저장하려고 하는데 그전에 저장할 빈 vector를 만듬
coef <- matrix(nrow=2,ncol=4) # model 결과들에 대한 값들을 집어넣기위해 빈 matrix 생성
for(i in c(1,3)){
  y <- dataa[,7] # 종속변수 지정 
  x <- dataa[,i] # 독립변수 지정
  df <-data.frame(x,y) # lm 을 위해 독립변수와 종속변수를 합쳐서 data frame 으로 만듬
  xnam <- colnames(dataa)[i] # 그래프의 x축 이름을 각 독립변수로 자동 지정
  ynam <- colnames(dataa)[7] # 그래프의 y축 이름 고정 지정
  ly <- lm(y~x) # simple linear model
  r2[j] <- summary(ly)$adj.r.squared # 각 linear model의 r square
  coef[j,] <- summary(ly)$coefficients[2,] # 각 모델들의 계수, std error , t value , p value
  g[[j]]<-ggplot(df,aes(x,y))+        # ggplot 을 통한 시각화 xlab : x 축 이름. 미리 지정해놓은 xnam 활용
    xlab(xnam)+ylab(ynam)+            # ylab : y 축 이름. 미리 지정해놓은 ynam 활용
    geom_point()+                     # 점을 찍음
    geom_smooth(method="lm")          # linear model의 추정선을 그림
  j=j+1                               # 그래프 저장을 위한 것
}
colnames(coef)<-c("Coefficient","Std.Error","t value","Pvalue")  # 모델 결과들이 어떤건지 알려주기위해 열이름 지정


data.frame(Univariate=colnames(dataa)[c(1,3)],r2=r2,coef) # 위의 결과를 data frame 으로 만들어서 확인
grid.arrange(g[[1]],g[[2]],nrow=1,ncol=2) # ggplot


## ----plotlyscatter3dno2,warning = FALSE, message = FALSE-------------------------------------------------
plot_ly(x=dataa$엔진스피드,y=dataa$배기가스온도,z = dataa$NO2배출량, type = "scatter3d", mode="markers")


## ----plotlyno2-------------------------------------------------------------------------------------------
p <- plot_ly(dataa, x = ~엔진스피드, y = ~배기가스온도)
add_markers(p, color = ~NO2배출량)


## ----changecutno2----------------------------------------------------------------------------------------
lmod <-lm(NO2배출량~ 엔진스피드 ,dataa)
o <- segmented(lmod,seg.Z=~엔진스피드, psi=list(엔진스피드=2100));o


## ----databno2--------------------------------------------------------------------------------------------
datab <- subset(dataa,엔진스피드<2199)
plot(datab$엔진스피드,datab$NO2배출량)


## ----plotlyscatter3d2no2,warning = FALSE, message = FALSE------------------------------------------------
plot_ly(x=datab$엔진스피드,y=datab$배기가스온도,z = datab$NO2배출량, type = "scatter3d", mode="markers")


## ----plotly2no2------------------------------------------------------------------------------------------
p <- plot_ly(datab, x = ~엔진스피드, y = ~배기가스온도)
add_markers(p, color = ~NO2배출량)


## ----vif61-----------------------------------------------------------------------------------------------
vif(lm(NO2배출량 ~ 엔진스피드+배기가스온도,data=datab))


## ----lm6-------------------------------------------------------------------------------------------------
lmod <- lm(NO2배출량 ~ 엔진스피드+배기가스온도,data=datab)
summary(lmod)


## ----residualplot6---------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod),residuals(lmod),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck6--------------------------------------------------------------------------------------
gvlma(lmod)


## ----lm6in-----------------------------------------------------------------------------------------------
lmod <-lm(NO2배출량 ~ 엔진스피드+배기가스온도+엔진스피드:배기가스온도,data=datab)
summary(lmod)


## ----residualplot6in-------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod),residuals(lmod),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck6in------------------------------------------------------------------------------------
gvlma(lmod)


## ----concurforno2----------------------------------------------------------------------------------------
model <- gam(NO2배출량 ~ s(엔진스피드)+s(배기가스온도),data=datab)
concurvity(model,full=T)


## ----gamsummary6-----------------------------------------------------------------------------------------
summary(model)


## ----gamplot6--------------------------------------------------------------------------------------------
plot(model,page=1)


## ----intergamno2-----------------------------------------------------------------------------------------
model <- gam(NO2배출량 ~ s(엔진스피드)+s(배기가스온도)+ti(엔진스피드,배기가스온도),data=datab)
summary(model)


## ----gamplot6in,fig.height=10 , fig.width=10-------------------------------------------------------------
plot(model,page=1)


## ----visgamcontourno2------------------------------------------------------------------------------------
vis.gam(model,plot.type="contour", too.far=0.1)



## ----seg2no2---------------------------------------------------------------------------------------------
lmod <- lm(NO2배출량 ~ 엔진스피드,data=datab)
o <- segmented(lmod,seg.Z=~엔진스피드);o



## ----plot1878--------------------------------------------------------------------------------------------
a<-subset(datab,datab$엔진스피드>1878)
ggplot(datab)+
  geom_point(mapping=aes(x=배기가스온도,y=NO2배출량))+
  geom_point(mapping=aes(x=배기가스온도,y=NO2배출량),data=a,col='red')


## ----locallinearno2--------------------------------------------------------------------------------------
lhs <- function(x) ifelse(x < 1878,1878-x,0)
rhs <- function(x) ifelse(x < 1878,0,x-1878)
lmod1 <- lm(NO2배출량 ~ 배기가스온도+lhs(엔진스피드) + rhs(엔진스피드), datab)
summary(lmod1)


## ----plotlylocalno2,warning = FALSE, message = FALSE-----------------------------------------------------
subplot(
  plot_ly(x=datab$엔진스피드, y=datab$배기가스온도, z=lmod1$fitted.values, type="scatter3d", mode="markers")
  ,plot_ly(x=datab$엔진스피드, y=datab$배기가스온도, z=datab$NO2배출량, type="scatter3d", mode="markers",color=I("red"))
)


## ----residualplot1pieceno21------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod1),residuals(lmod1),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod1),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod1),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck1pieceno211----------------------------------------------------------------------------
gvlma(lmod1)


## ----no2 bootsrap----------------------------------------------------------------------------------------
betahat = lmod1$coefficients

B=1000   # 붓스트랩 반복수
N=nrow(datab)  # 데이터 사이즈 
betaast=matrix(NA,B,length(lmod1$coefficients)) # 붓스트랩 통계량 행렬
set.seed(1)  
IND=matrix(sample(1:N,B*N,replace=T),B,N)   # 붓스트랩 표본추출

for (i in 1:B)
{
  data_ast = datab[IND[i,],]    # i번째 붓스트랩 표본
  lmod_temp = lm(NO2배출량 ~ 배기가스온도+lhs(엔진스피드) + rhs(엔진스피드), data_ast) # 붓스트랩 표본 모형적합
  betaast[i,]=lmod_temp$coefficients  # i번째 붓스트랩 통계량
}

quant_ast = apply(betaast,2,quantile,probs=c(0.025,0.975))  # 붓스트랩 통계량의 분위수
temp = rbind(2*betahat[2]-quant_ast[2:1,2],quant_ast[,2])    # 온도에 대한 95% 신뢰구간
rownames(temp) = c("pivotal","percentile")
CI_lhs = rbind(2*betahat[3]-quant_ast[2:1,3],quant_ast[,3])    # lhs에 대한 95% 신뢰구간
rownames(CI_lhs) = c("pivotal","percentile")
CI_rhs = rbind(2*betahat[4]-quant_ast[2:1,4],quant_ast[,4])    # rhs에 대한 95% 신뢰구간
rownames(CI_rhs) = c("pivotal","percentile")
temp # 온도에 대한 95% 신뢰구간
CI_lhs # lhs에 대한 95% 신뢰구간
CI_rhs # rhs에 대한 95% 신뢰구간


## ----locallinearinter2no2--------------------------------------------------------------------------------
lmod2 <- lm(NO2배출량 ~ 배기가스온도+lhs(엔진스피드) + rhs(엔진스피드)+배기가스온도:lhs(엔진스피드)+배기가스온도:rhs(엔진스피드), datab)
summary(lmod2)


## ----plotlylocal22no2,warning = FALSE, message = FALSE---------------------------------------------------
subplot(
  plot_ly(x=datab$엔진스피드, y=datab$배기가스온도, z=lmod2$fitted.values, type="scatter3d", mode="markers")
  ,plot_ly(x=datab$엔진스피드, y=datab$배기가스온도, z=datab$NO2배출량, type="scatter3d", mode="markers",color=I("red"))
)


## ----residualplot1pieceno2-------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod2),residuals(lmod2),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod2),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod2),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck1pieceno2------------------------------------------------------------------------------
gvlma(lmod2)


## ----no2 bootsrap2---------------------------------------------------------------------------------------
betahat = lmod2$coefficients

B=1000   # 붓스트랩 반복수
N=nrow(datab)  # 데이터 사이즈 
betaast=matrix(NA,B,length(lmod2$coefficients)) # 붓스트랩 통계량 행렬
set.seed(1)  
IND=matrix(sample(1:N,B*N,replace=T),B,N)   # 붓스트랩 표본추출

for (i in 1:B)
{
  data_ast = datab[IND[i,],]    # i번째 붓스트랩 표본
  lmod_temp = lm(NO배출량 ~ 배기가스온도+lhs(엔진스피드) + rhs(엔진스피드)+배기가스온도:lhs(엔진스피드)+배기가스온도:rhs(엔진스피드), data_ast) # 붓스트랩 표본 모형적합
  betaast[i,]=lmod_temp$coefficients  # i번째 붓스트랩 통계량
}

quant_ast = apply(betaast,2,quantile,probs=c(0.025,0.975))  # 붓스트랩 통계량의 분위수
temp = rbind(2*betahat[2]-quant_ast[2:1,2],quant_ast[,2])    # 온도에 대한 95% 신뢰구간
rownames(temp) = c("pivotal","percentile")
CI_lhs = rbind(2*betahat[3]-quant_ast[2:1,3],quant_ast[,3])    # lhs에 대한 95% 신뢰구간
rownames(CI_lhs) = c("pivotal","percentile")
CI_rhs = rbind(2*betahat[4]-quant_ast[2:1,4],quant_ast[,4])    # rhs에 대한 95% 신뢰구간
rownames(CI_rhs) = c("pivotal","percentile")
CI_lhsTemp = rbind(2*betahat[5]-quant_ast[2:1,5],quant_ast[,5])    # lhs와 온도의 교호작용항에 대한 95% 신뢰구간
rownames(CI_lhsTemp) = c("pivotal","percentile")
CI_rhsTemp = rbind(2*betahat[6]-quant_ast[2:1,6],quant_ast[,6])    # rhs와 온도의 교호작용항에 대한 95% 신뢰구간
rownames(CI_rhsTemp) = c("pivotal","percentile")

temp # 온도에 대한 95% 신뢰구간
CI_lhs # lhs에 대한 95% 신뢰구간
CI_rhs # rhs에 대한 95% 신뢰구간
CI_lhsTemp # lhs와 온도의 교호작용항에 대한 95% 신뢰구간
CI_rhsTemp # rhs와 온도의 교호작용항에 대한 95% 신뢰구간


## ----anovano2--------------------------------------------------------------------------------------------
anova(lmod1,lmod2)


## ----univariate7-----------------------------------------------------------------------------------------
g<-list() # ggplot 여러개를 동시에 보여주기 위해 list를 만들어서 저장하려고함. 그것을 위해 빈 list 를 미리 만듬
j=1       # 그래프 저장을 위한 초기값 1
r2 <-c() # 각 독립변수마다의 r2를 for을 통해 저장하려고 하는데 그전에 저장할 빈 vector를 만듬
coef <- matrix(nrow=2,ncol=4) # model 결과들에 대한 값들을 집어넣기위해 빈 matrix 생성
for(i in c(1,3)){
  y <- dataa[,8] # 종속변수 지정 
  x <- dataa[,i] # 독립변수 지정
  df <-data.frame(x,y) # lm 을 위해 독립변수와 종속변수를 합쳐서 data frame 으로 만듬
  xnam <- colnames(dataa)[i] # 그래프의 x축 이름을 각 독립변수로 자동 지정
  ynam <- colnames(dataa)[8] # 그래프의 y축 이름 고정 지정
  ly <- lm(y~x) # simple linear model
  r2[j] <- summary(ly)$adj.r.squared # 각 linear model의 r square
  coef[j,] <- summary(ly)$coefficients[2,] # 각 모델들의 계수, std error , t value , p value
  g[[j]]<-ggplot(df,aes(x,y))+        # ggplot 을 통한 시각화 xlab : x 축 이름. 미리 지정해놓은 xnam 활용
    xlab(xnam)+ylab(ynam)+            # ylab : y 축 이름. 미리 지정해놓은 ynam 활용
    geom_point()+                     # 점을 찍음
    geom_smooth(method="lm")          # linear model의 추정선을 그림
  j=j+1                               # 그래프 저장을 위한 것
}
colnames(coef)<-c("Coefficient","Std.Error","t value","Pvalue")  # 모델 결과들이 어떤건지 알려주기위해 열이름 지정


data.frame(Univariate=colnames(dataa)[c(1,3)],r2=r2,coef) # 위의 결과를 data frame 으로 만들어서 확인
grid.arrange(g[[1]],g[[2]],nrow=1,ncol=2) # ggplot


## ----plotlyscatter3do2,warning = FALSE, message = FALSE--------------------------------------------------
plot_ly(x=dataa$엔진스피드,y=dataa$배기가스온도,z = dataa$O2배출량, type = "scatter3d", mode="markers")


## ----plotlyo2--------------------------------------------------------------------------------------------
p <- plot_ly(dataa, x = ~엔진스피드, y = ~배기가스온도)
add_markers(p, color = ~O2배출량)


## ----vif71-----------------------------------------------------------------------------------------------
vif(lm(O2배출량 ~ 엔진스피드+배기가스온도,data=dataa))


## ----lm7-------------------------------------------------------------------------------------------------
lmod <- lm(O2배출량 ~ 엔진스피드+배기가스온도,data=dataa)
summary(lmod)


## ----residualplot7---------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod),residuals(lmod),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck7--------------------------------------------------------------------------------------
gvlma(lmod)


## ----lm7in-----------------------------------------------------------------------------------------------
lmod <-lm(O2배출량 ~ 엔진스피드+배기가스온도+엔진스피드:배기가스온도,data=dataa)
summary(lmod)


## ----residualplot7in-------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod),residuals(lmod),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck7in------------------------------------------------------------------------------------
gvlma(lmod)


## ----concurforo2-----------------------------------------------------------------------------------------
model <- gam(O2배출량 ~ s(엔진스피드)+s(배기가스온도),data=dataa)
concurvity(model,full=T)


## ----gamsummary7-----------------------------------------------------------------------------------------
summary(model)


## ----gamplot7--------------------------------------------------------------------------------------------
plot(model,page=1)


## ----intergamo2------------------------------------------------------------------------------------------
model <- gam(O2배출량 ~ s(엔진스피드)+s(배기가스온도)+ti(엔진스피드,배기가스온도),data=dataa)
summary(model)


## ----gamplot7in,fig.height=10 , fig.width=10-------------------------------------------------------------
plot(model,page=1)


## ----visgamcontouro2-------------------------------------------------------------------------------------
vis.gam(model,plot.type="contour", too.far=0.1)



## ----seg2o2----------------------------------------------------------------------------------------------
lmod <-lm(O2배출량~엔진스피드+배기가스온도,dataa)
o <- segmented(lmod,seg.Z=~엔진스피드);o


## ----plot1988o2------------------------------------------------------------------------------------------
a<-subset(dataa,dataa$엔진스피드>1988)
ggplot(dataa)+
  geom_point(mapping=aes(x=배기가스온도,y=O2배출량))+
  geom_point(mapping=aes(x=배기가스온도,y=O2배출량),data=a,col='red')


## ----locallinearo2---------------------------------------------------------------------------------------
lhs <- function(x) ifelse(x < 1988,1988-x,0)
rhs <- function(x) ifelse(x < 1988,0,x-1988)
lmod1 <- lm(O2배출량 ~ 배기가스온도+lhs(엔진스피드) + rhs(엔진스피드), dataa)
summary(lmod1)


## ----plotlylocalo2,warning = FALSE, message = FALSE------------------------------------------------------
subplot(
  plot_ly(x=dataa$엔진스피드, y=dataa$배기가스온도, z=lmod1$fitted.values, type="scatter3d", mode="markers")
  ,plot_ly(x=dataa$엔진스피드, y=dataa$배기가스온도, z=dataa$O2배출량, type="scatter3d", mode="markers",color=I("red"))
)



## ----residualplot1pieceo2--------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod1),residuals(lmod1),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod1),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod1),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck1pieceo2-------------------------------------------------------------------------------
gvlma(lmod1)


## ----locallinearintero2----------------------------------------------------------------------------------
lhs <- function(x) ifelse(x < 1988,1988-x,0)
rhs <- function(x) ifelse(x < 1988,0,x-1988)
lmod2 <- lm(O2배출량 ~ 배기가스온도+lhs(엔진스피드) + rhs(엔진스피드)+배기가스온도:lhs(엔진스피드)+배기가스온도:rhs(엔진스피드), dataa)
summary(lmod2)



## ----residualplot1pieceo22-------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod2),residuals(lmod2),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod2),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod2),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck1pieceo22------------------------------------------------------------------------------
gvlma(lmod2)


## ----anovao2---------------------------------------------------------------------------------------------
anova(lmod1,lmod2)


## ----locallinearo2simple---------------------------------------------------------------------------------
lmod3 <- lm(O2배출량 ~ lhs(엔진스피드) + rhs(엔진스피드), dataa)
summary(lmod3)


## ----plotlylocalo2simple,warning = FALSE, message = FALSE------------------------------------------------
subplot(
plot_ly(x=dataa$엔진스피드, y=dataa$배기가스온도, z=lmod3$fitted.values, type="scatter3d", mode="markers")
,plot_ly(x=dataa$엔진스피드, y=dataa$배기가스온도, z=dataa$O2배출량, type="scatter3d", mode="markers",color=I("red"))
)


## ----residualplot1pieceo2simple--------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(lmod3),residuals(lmod3),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(lmod3),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(lmod3),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----residualcheck1pieceo2simple-------------------------------------------------------------------------
gvlma(lmod3)


## ----boostrap O2-----------------------------------------------------------------------------------------
betahat = lmod3$coefficients

B=1000   # 붓스트랩 반복수
N=nrow(dataa)  # 데이터 사이즈 
betaast=matrix(NA,B,length(lmod3$coefficients)) # 붓스트랩 통계량 행렬

for (i in 1:B)
{
  data_ast = dataa[IND[i,],]    # i번째 붓스트랩 표본
  lmod_temp = lm(O2배출량 ~ lhs(엔진스피드) + rhs(엔진스피드), data_ast) # 붓스트랩 표본 모형적합
  betaast[i,]=lmod_temp$coefficients  # i번째 붓스트랩 통계량
}

quant_ast = apply(betaast,2,quantile,probs=c(0.025,0.975))  # 붓스트랩 통계량의 분위수
CI_lhs = rbind(2*betahat[2]-quant_ast[2:1,2],quant_ast[,2])    # lhs에 대한 95% 신뢰구간
rownames(CI_lhs) = c("pivotal","percentile")
CI_rhs = rbind(2*betahat[3]-quant_ast[2:1,3],quant_ast[,3])    # rhs에 대한 95% 신뢰구간
rownames(CI_rhs) = c("pivotal","percentile")
CI_lhs # lhs에 대한 95% 신뢰구간
CI_rhs # rhs에 대한 95% 신뢰구간

