## ----setup, include=FALSE--------------------------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ---- include=FALSE--------------------------------------------------------------------------------------
library(readxl)
library(tidyverse)
library(mgcv)
library(ggplot2)
library(gridExtra)


## ---- message=FALSE--------------------------------------------------------------------------------------
DATASET = read.csv("project3.csv",check.names=FALSE)
names(DATASET) = c('NO', '엔진스피드', '엔진부하', 'fuelrate', '배기가스질량유량', '배기가스온도', 'CO2배출량', 'CO배출량', 'NO배출량', 'NO2배출량', 'O2배출량',  'CO2masskwh', 'COmasskwh', 'NOmasskwh', 'NO2masskwh', 'O2masskwh', '엔진파워', 'BSFC', 'NOX')
DATASET = as.data.frame(DATASET)


## --------------------------------------------------------------------------------------------------------
dim(DATASET)



## --------------------------------------------------------------------------------------------------------
sum(is.na(DATASET))
DATASET$NO[!complete.cases(DATASET)]


## --------------------------------------------------------------------------------------------------------
DATASET1 = na.omit(DATASET)
a = list()
b = rep(1, 17)
for(i in c(2:17)) {
  xname = names(DATASET1)[i]
  a[[i]] = ggplot(DATASET1, mapping =  aes_(x = DATASET1[,i])) +
    geom_histogram(binwidth = b[i]) +
    labs(x = xname)
}



## --------------------------------------------------------------------------------------------------------
grid.arrange( a[[2]], a[[3]], a[[4]], nrow = 1, ncol = 3)


## --------------------------------------------------------------------------------------------------------
a = DATASET$NO[(DATASET$엔진스피드< 1080)]
a = na.omit(a)
length(a)
dim(DATASET)
DATASET_A = DATASET[-a,]
dim(DATASET_A)


## --------------------------------------------------------------------------------------------------------
dim(DATASET_A)
DATASET_A %>%
  filter(엔진부하 >= 31) -> DATASET_B
dim(DATASET_B)
DATASET = DATASET_B


## --------------------------------------------------------------------------------------------------------
### 각 변수별 히스토그램.
DATASET1 = na.omit(DATASET)
a = list()
b = rep(1, 17)
for(i in c(2:17)) {
  xname = names(DATASET1)[i]
  a[[i]] = ggplot(DATASET1, mapping =  aes_(x = DATASET1[,i])) +
    geom_histogram(binwidth = b[i]) +
    labs(x = xname)
}



## --------------------------------------------------------------------------------------------------------
grid.arrange( a[[2]], a[[3]], a[[4]], nrow = 1, ncol = 3)


## --------------------------------------------------------------------------------------------------------
grid.arrange(a[[5]], a[[6]], a[[7]],nrow = 1, ncol = 3)


## --------------------------------------------------------------------------------------------------------
grid.arrange(a[[8]], a[[9]], a[[10]], nrow = 1, ncol = 3)


## --------------------------------------------------------------------------------------------------------
grid.arrange(a[[11]], a[[17]],nrow = 1, ncol = 3)


## ---- fig.width = 100, fig.height = 100------------------------------------------------------------------
#DATASET 관측치중 1/10을 추출해 상관행렬을 그림
n = dim(DATASET)[1] * 1/10
mat = sample_n(DATASET, n)
pairs(mat[, -c(12, 13, 14, 15, 16, 17, 18, 19)], cex.labels = 15)


## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
### fuelrate를 반응변수로, 배기가스질량유량, 배기가스온도, 엔진부하 각각에 대해 산점도와 선형모형을 적합시킨 결과를 출력.
j = 1
univ1 = list()
for(i in c(3, 5, 6, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[4]
  univ1[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 4], color = DATASET[, 2])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle('엔진스피드별')  
  j = j + 1
}

grid.arrange(univ1[[1]], univ1[[2]], univ1[[3]], univ1[[4]], nrow = 2, ncol = 2)


## --------------------------------------------------------------------------------------------------------
fit2_vc1 = gam(fuelrate ~ s(엔진스피드) + s(엔진스피드, by = 엔진부하) , data = DATASET)
summary(fit2_vc1)



## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit2_vc1, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1)) #sq을 x값으로, 이에 해당하는 VC모형의 회귀함수값을 추출.
fitted1v = pvc1$fit[, 1]#VC 모형의 s(엔진스피드) 함수 값
fitted1se = pvc1$se.fit[, 1]#VC 모형의 s(엔진스피드)  함수 표준편차값
fitted1.up95 = fitted1v + 1.96 * fitted1se #상위 97.5%
fitted1.lw95 = fitted1v - 1.96 * fitted1se #하위 97.5%
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue') +
  labs(x = '엔진스피드') +
  labs(y = 'beta0')

fitted2v = pvc1$fit[, 2]#VC 모형의 s(엔진스피드):엔진부하 함수값
fitted2se = pvc1$se.fit[, 2]#VC 모형의 s(엔진스피드):엔진부하 표준편차값
fitted2.up95 = fitted2v + 1.96 * fitted2se #상위 2.5%
fitted2.lw95 = fitted2v - 1.96 * fitted2se #하위 2.5%
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진스피드') +
  labs(y = 'beta1')+
  geom_vline(xintercept = 1975, color = 'red', alpha = 0.5)


grid.arrange(a1, a2, nrow = 1, ncol = 2)



## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 100)
pvc1 = predict(fit2_vc1, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1)) #sq을 x값으로, 이에 해당하는 VC모형의 회귀함수값을 추출.
coef_vc1 = pvc1$fit
intcept_v = coef(fit2_vc1)[1] #vc모형의 beta 값, 1-2  summary (intercept) 부분에서 확인


## ---- echo = FALSE---------------------------------------------------------------------------------------
l = list()
k1 = list()
for(i in c(1:12)) {
  ind = ((1000 + 100*i - 15) < DATASET$엔진스피드) & (DATASET$엔진스피드 < (1000 + 100*i + 15)) #(1100-15, 1100+15), ..., (2200-15, 2200+15) 범위까지의 data index 추출
  D1 = DATASET[ind, ] #위의 엔진스피드 범위안의 data추출
  l[[i]] = lm(fuelrate ~ 엔진부하, data = D1) #위의 data로 선형모형 적합
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 12))#legend 1은 선형모형 직선에 번호를 붙이기 위한 자료구조임.
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:12)) {
  legend1[i,] = c(95, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 95, i)#x값(엔진부하) 95에 해당하는 선형모형의 y값 위치 
}

legend2 = data.frame(matrix(ncol = 3, nrow = 12))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:12)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] + intcept_v, slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(100, coef_vc1[i, ][1] + intcept_v   + coef_vc1[i, ][2]*100, i)#x값(엔진부하) 95에 해당하는 VC모형의 y값 위치 
}


## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 3], y = DATASET[, 4], color = DATASET[, 2])) +
  geom_point(size = 0.5)  + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]] + k1[[8]] + k1[[9]] + k1[[10]] + k1[[11]] + k1[[12]] + k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]] + k2[[8]] + k2[[9]] + k2[[10]] + k2[[11]] + k2[[12]] + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label), color = 'blue') + labs(x = names(DATASET[3])) +  labs(y = names(DATASET[4]))


## --------------------------------------------------------------------------------------------------------
fit4_vc1 = lm(fuelrate ~ 엔진스피드 + 엔진부하 + 엔진부하:엔진스피드, data = DATASET)
summary(fit4_vc1)



## --------------------------------------------------------------------------------------------------------
r0 = coef(fit4_vc1)[1]
r1 = coef(fit4_vc1)[2]
d0 = coef(fit4_vc1)[3]
d1 = coef(fit4_vc1)[4]
c = coef(fit2_vc1)[1]

sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit2_vc1, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))#sq을 x값으로, 이에 해당하는 VC모형의 회귀함수값을 추출.
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))#sq을 x값으로, 이에 해당하는 VC모형의 s(엔진스피드), s(엔진스피드):엔진부하 값들을 data frame 형태로 저장.
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진스피드') +
  labs(y = 'beta0')

c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진스피드') +
  geom_vline(xintercept = 1980, color = 'red', alpha = 0.5) +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
j = 1
univ2 = list()
for(i in c(4, 6, 3, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[5]
  univ2[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 5], color = DATASET[,2])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle('엔진스피드별')
    geom_smooth(method = 'lm')
  j = j + 1
}

grid.arrange(univ2[[1]], univ2[[2]], univ2[[3]], univ2[[4]], nrow = 2, ncol = 2)



## --------------------------------------------------------------------------------------------------------
DATASET_A = na.omit(DATASET)
cor(DATASET_A[, 2], DATASET_A[, 5]) #엔진스피드와 배기가스질량유량의 상관계수
cor(DATASET_A[, 3], DATASET_A[, 5]) #엔진부하와 배기가스질량유량의 상관계수
cor(DATASET_A[, 4], DATASET_A[, 5]) #fuelrate와 배기가스질량유량의 상관계수
cor(DATASET_A[, 6], DATASET_A[, 5]) #배기가스 온도와 배기가스질량유량의 상관계수


## --------------------------------------------------------------------------------------------------------
fit2_vc2 = gam(배기가스질량유량 ~ s(엔진스피드) +  s(엔진스피드, by = 엔진부하), data = DATASET)
summary(fit2_vc2)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit2_vc2, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1)) #sq1을 x값으로 VC모델로 추정한 함수값을 
fitted1v = pvc1$fit[, 1]
fitted1se = pvc1$se.fit[, 1]
fitted1.up95 = fitted1v + 1.96 * fitted1se
fitted1.lw95 = fitted1v - 1.96 * fitted1se
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue') +
  labs(x = '엔진스피드') +
  labs(y = 'beta0')

fitted2v = pvc1$fit[, 2]
fitted2se = pvc1$se.fit[, 2]
fitted2.up95 = fitted2v + 1.96 * fitted2se
fitted2.lw95 = fitted2v - 1.96 * fitted2se
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진스피드') +
  geom_vline(xintercept = 1875, color = 'red', alpha = 0.5) +
  geom_vline(xintercept = 1500, color = 'red', alpha = 0.5) +
  labs(y = 'beta1')


grid.arrange(a1, a2, nrow = 1, ncol = 2)



## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 100)
pvc1 = predict(fit2_vc2, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
coef_vc1 = pvc1$fit


## ---- echo = FALSE---------------------------------------------------------------------------------------
l = list()
k1 = list()
for(i in c(1:12)) {
  ind = ((1000 + 100*i - 15) < DATASET$엔진스피드) & (DATASET$엔진스피드 < (1000 + 100*i + 15))
  D1 = DATASET[ind, ]
  l[[i]] = lm(배기가스질량유량 ~ 엔진부하, data = D1)
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 12))
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:12)) {
  legend1[i,] = c(95, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 95, i)  
}

legend2 = data.frame(matrix(ncol = 3, nrow = 12))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:12)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] +coef(fit2_vc2)[1], slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(100, coef_vc1[i, ][1] + coef(fit2_vc2)[1] + coef_vc1[i, ][2]*100, i)
}


## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 3], y = DATASET[, 5], color = DATASET[, 2])) +
  geom_point(size = 0.5)  + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]] + k1[[8]] + k1[[9]] + k1[[10]] + k1[[11]] + k1[[12]] + k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]] + k2[[8]] + k2[[9]] + k2[[10]] + k2[[11]] + k2[[12]] + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label), color = 'blue') + labs(x = names(DATASET[3])) +  labs(y = names(DATASET[5]))


## --------------------------------------------------------------------------------------------------------
fit3_vc2 = lm(배기가스질량유량 ~ 엔진스피드 + 엔진부하 + 엔진부하:엔진스피드, data = DATASET)
summary(fit3_vc2)



## --------------------------------------------------------------------------------------------------------
r0 = coef(fit3_vc2)[1]
r1 = coef(fit3_vc2)[2]
d0 = coef(fit3_vc2)[3]
d1 = coef(fit3_vc2)[4]
c = coef(fit2_vc2)[1]

sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit2_vc2, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진스피드') +
  labs(y = 'beta0') +
  geom_vline(xintercept = 1450, color = 'red', alpha = .5)
c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진스피드') +
  geom_vline(xintercept = 1875, color = 'red', alpha = 0.5) +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)



## --------------------------------------------------------------------------------------------------------
fit5_vc2 = gam(배기가스질량유량 ~ 엔진스피드 + 엔진부하, data = DATASET)
summary(fit5_vc2)


## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
#Exhmf, Exhtemp, Engload <- independent variables
j = 1
univ3 = list()
for(i in c(5, 6, 3, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[7]
  univ3[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 7], color = DATASET[, 2])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) 
  j = j + 1
}


grid.arrange(univ3[[1]], univ3[[2]], univ3[[3]], univ3[[4]], nrow = 2, ncol = 2)



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(data = DATASET, aes_(x = DATASET[, 4], y = DATASET[, 7])) +
  geom_point() + 
  labs(x = names(DATASET)[4]) +
  labs(y = names(DATASET)[7]) +
  geom_smooth(method = 'lm')

DATASET_A = na.omit(DATASET)



## --------------------------------------------------------------------------------------------------------
cor(DATASET_A[, 4], DATASET_A[,7])


## --------------------------------------------------------------------------------------------------------
fit1_vc3 = gam(CO2배출량 ~ s(엔진스피드) + s(엔진스피드, by = 엔진부하),  data = DATASET)
summary(fit1_vc3)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit1_vc3, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
fitted1v = pvc1$fit[, 1]
fitted1se = pvc1$se.fit[, 1]
fitted1.up95 = fitted1v + 1.96 * fitted1se
fitted1.lw95 = fitted1v - 1.96 * fitted1se
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue') +
  labs(x = '엔진스피드') +
  labs(y = 'beta0')

fitted2v = pvc1$fit[, 2]
fitted2se = pvc1$se.fit[, 2]
fitted2.up95 = fitted2v + 1.96 * fitted2se
fitted2.lw95 = fitted2v - 1.96 * fitted2se
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진스피드') +
  geom_vline(xintercept = 1980, color = 'red', alpha = 0.5) +
  labs(y = 'beta1')

grid.arrange(a1, a2, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 100)
pvc1 = predict(fit1_vc3, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] - 16.7239, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')



## ---- echo = FALSE---------------------------------------------------------------------------------------
l = list()
k1 = list()
for(i in c(1:12)) {
  ind = ((1000 + 100*i - 15) < DATASET$엔진스피드) & (DATASET$엔진스피드 < (1000 + 100*i + 15))
  D1 = DATASET[ind, ]
  l[[i]] = lm(CO2배출량 ~ 엔진부하, data = D1)
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 12))
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:12)) {
  legend1[i,] = c(95, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 95, i)  
}

legend2 = data.frame(matrix(ncol = 3, nrow = 12))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:12)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] - 16.7239, slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(100, coef_vc1[i, ][1] - 16.7239 + coef_vc1[i, ][2]*100, i)
}


## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 3], y = DATASET[, 7], color = DATASET[, 2])) +
  geom_point(size = 0.5)  + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]] + k1[[8]] + k1[[9]] + k1[[10]] + k1[[11]] + k1[[12]] + k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]] + k2[[8]] + k2[[9]] + k2[[10]] + k2[[11]] + k2[[12]] + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label), color = 'blue') + labs(x = names(DATASET[3])) +  labs(y = names(DATASET[7]))


## --------------------------------------------------------------------------------------------------------
fit4_vc3 = lm(CO2배출량 ~ 엔진스피드 + 엔진부하 + 엔진부하:엔진스피드, data = DATASET)
summary(fit4_vc3)


## --------------------------------------------------------------------------------------------------------
r0 = coef(fit4_vc3)[1]
r1 = coef(fit4_vc3)[2]
d0 = coef(fit4_vc3)[3]
d1 = coef(fit4_vc3)[4]
c = coef(fit1_vc3)[1]

sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit1_vc3, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진스피드')  +
  labs(y = 'beta0') +
  geom_vline(xintercept = 1800, color = 'red', alpha = 0.5) +
  geom_vline(xintercept = 1450, color = 'red', alpha = 0.5)
c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진스피드') +
  geom_vline(xintercept = 1980, color = 'red', alpha = 0.5)  +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
#Exhmf, Exhtemp, Engload <- independent variables
j = 1
univ3 = list()
for(i in c(5, 6, 3, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[8]
  univ3[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 8], color = DATASET[, 2])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle('엔진스피드별')
  j = j + 1
}


grid.arrange(univ3[[1]], univ3[[2]], univ3[[3]], univ3[[4]], nrow = 2, ncol = 2)




## --------------------------------------------------------------------------------------------------------
fit1_vc4 = gam(CO배출량 ~ s(엔진스피드) + s(엔진스피드, by = 엔진부하), data = DATASET)
summary(fit1_vc4)



## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit1_vc4, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
fitted1v = pvc1$fit[, 1]
fitted1se = pvc1$se.fit[, 1]
fitted1.up95 = fitted1v + 1.96 * fitted1se
fitted1.lw95 = fitted1v - 1.96 * fitted1se
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue') +
  labs(x = '엔진스피드') +
  labs(y = 'beta0')

fitted2v = pvc1$fit[, 2]
fitted2se = pvc1$se.fit[, 2]
fitted2.up95 = fitted2v + 1.96 * fitted2se
fitted2.lw95 = fitted2v - 1.96 * fitted2se
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진스피드') +
  labs(y = 'beta1')

grid.arrange(a1, a2, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 100)
pvc1 = predict(fit1_vc4, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
coef_vc1 = pvc1$fit
intceptv =  coef(fit1_vc4)[1]

comp1 = list()
lmod1 = list()
for(i in c(1:12)) {
  ind = ((1000 + 100*i - 15) < DATASET$엔진스피드) & (DATASET$엔진스피드 < (1000 + 100*i + 15))
  D1 = DATASET[ind, ]
  comp1[[i]] = ggplot(D1, aes_(x = D1[, 3], y = D1[, 5])) +
    geom_point(size = 0.1, alpha = 0.5) +
    geom_abline(intercept = coef_vc1[i, ][1] + intceptv , slope = coef_vc1[i, ][2], color = 'blue') +
    geom_smooth(method = 'lm', color = 'red', size = 0.5) +
    labs(x = names(D1)[3]) +
    labs(y = names(D1)[5])+
    ggtitle(1000 + 100*i, 'rpm')
}



## ---- echo = FALSE---------------------------------------------------------------------------------------
l = list()
k1 = list()
for(i in c(1:12)) {
  ind = ((1000 + 100*i - 15) < DATASET$엔진스피드) & (DATASET$엔진스피드 < (1000 + 100*i + 15))
  D1 = DATASET[ind, ]
  l[[i]] = lm(CO배출량 ~ 엔진부하, data = D1)
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 12))
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:12)) {
  legend1[i,] = c(95, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 95, i)  
}

legend2 = data.frame(matrix(ncol = 3, nrow = 12))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:12)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] +intceptv , slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(100, coef_vc1[i, ][1] + intceptv  + coef_vc1[i, ][2]*100, i)
}


## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 3], y = DATASET[, 8], color = DATASET[, 2])) +
  geom_point(size = 0.5)  + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]] + k1[[8]] + k1[[9]] + k1[[10]] + k1[[11]] + k1[[12]] + k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]] + k2[[8]] + k2[[9]] + k2[[10]] + k2[[11]] + k2[[12]] + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label), color = 'blue') + labs(x = names(DATASET[3])) +  labs(y = names(DATASET[8]))


## --------------------------------------------------------------------------------------------------------
fit2_vc4 = gam(CO배출량 ~ 엔진스피드 + 엔진부하 + 엔진스피드*엔진부하, data = DATASET)
summary(fit2_vc4)


## --------------------------------------------------------------------------------------------------------
r0 = coef(fit2_vc4)[1]
r1 = coef(fit2_vc4)[2]
d0 = coef(fit2_vc4)[3]
d1 = coef(fit2_vc4)[4]
c = coef(fit1_vc4)[1]

sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit1_vc4, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진스피드')  +
  labs(y = 'beta0') 
c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진스피드') +
  geom_vline(xintercept = 1750, color = 'red', alpha = 0.5)  +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
#Exhmf, Exhtemp, Engload <- independent variables
j = 1
univ3 = list()
for(i in c(5, 6, 3, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[9]
  univ3[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 9], color = DATASET[, 2])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle('엔진스피드별') 
  j = j + 1
}


grid.arrange(univ3[[1]], univ3[[2]], univ3[[3]], univ3[[4]], nrow = 2, ncol = 2)




## --------------------------------------------------------------------------------------------------------
result = vector(length = 12)
for(i in c(1:12)) {
  ind = ((1000 + 100*i - 30) < DATASET$엔진스피드) & (DATASET$엔진스피드 < (1000 + 100*i + 30))
  D1 = na.omit(DATASET[ind, ])
  result[i] = mean(D1[, 9])
}
sq = seq(1100, 2200, by = 100)
df = as.data.frame(cbind(sq, result))
names(df) = c('x1', 'y1')
a <- ggplot(df, aes(x = x1, y = y1)) +
  geom_point() +
  geom_line() +
  labs(x = names(D1)[2]) +
  labs(y = names(D1)[9])
a


## --------------------------------------------------------------------------------------------------------
fit1_vc5 = gam(NO배출량 ~ s(엔진스피드) + s(엔진스피드, by = 엔진부하), data = DATASET)
summary(fit1_vc5)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit1_vc5, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
fitted1v = pvc1$fit[, 1]
fitted1se = pvc1$se.fit[, 1]
fitted1.up95 = fitted1v + 1.96 * fitted1se
fitted1.lw95 = fitted1v - 1.96 * fitted1se
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue') +
  labs(x = '엔진스피드') +
  labs(y = 'beta0') +
  geom_vline(xintercept = 1560, color = 'blue', alpha = 0.5) +
  geom_vline(xintercept = 1890, color = 'blue', alpha = 0.5) +
  geom_vline(xintercept = 1220, color = 'blue', alpha = 0.5) +
  geom_vline(xintercept = 1370, color = 'red', alpha = 0.5) +
  geom_vline(xintercept = 1750, color = 'red', alpha = 0.5) 

fitted2v = pvc1$fit[, 2]
fitted2se = pvc1$se.fit[, 2]
fitted2.up95 = fitted2v + 1.96 * fitted2se
fitted2.lw95 = fitted2v - 1.96 * fitted2se
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진스피드') +
  labs(y = 'beta1') +
  geom_vline(xintercept = 1560, color = 'red', alpha = 0.5) +
  geom_vline(xintercept = 1890, color = 'red', alpha = 0.5) +
  geom_vline(xintercept = 1220, color = 'red', alpha = 0.5) +
  geom_vline(xintercept = 1370, color = 'blue', alpha = 0.5) +
  geom_vline(xintercept = 1750, color = 'blue', alpha = 0.5) 

grid.arrange(a1, a2, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 100)
pvc1 = predict(fit1_vc5, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
coef_vc1 = pvc1$fit
intceptv =  coef(fit1_vc5)[1]




## ---- echo = FALSE---------------------------------------------------------------------------------------
l = list()
k1 = list()
for(i in c(1:12)) {
  ind = ((1000 + 100*i - 15) < DATASET$엔진스피드) & (DATASET$엔진스피드 < (1000 + 100*i + 15))
  D1 = DATASET[ind, ]
  l[[i]] = lm(NO배출량 ~ 엔진부하, data = D1)
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 12))
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:12)) {
  legend1[i,] = c(30, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 30, i)  
}

legend2 = data.frame(matrix(ncol = 3, nrow = 12))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:12)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] +intceptv , slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(35, coef_vc1[i, ][1] + intceptv  + coef_vc1[i, ][2]*35, i)
}


## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 3], y = DATASET[, 9], color = DATASET[,2])) +
  geom_point(size = 0.5)  + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]] + k1[[8]] + k1[[9]] + k1[[10]] + k1[[11]] + k1[[12]] + k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]] + k2[[8]] + k2[[9]] + k2[[10]] + k2[[11]] + k2[[12]] + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label), color = 'blue') + labs(x = names(DATASET[3])) +  labs(y = names(DATASET[9]))

  


## --------------------------------------------------------------------------------------------------------
fit2_vc5 = gam(NO배출량 ~ 엔진스피드 + 엔진부하 + 엔진스피드*엔진부하, data = DATASET)
summary(fit2_vc5)


## --------------------------------------------------------------------------------------------------------
r0 = coef(fit2_vc5)[1]
r1 = coef(fit2_vc5)[2]
d0 = coef(fit2_vc5)[3]
d1 = coef(fit2_vc5)[4]
c = coef(fit1_vc5)[1]

sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit1_vc5, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진스피드')  +
  labs(y = 'beta0')
c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진스피드')   +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
#Exhmf, Exhtemp, Engload <- independent variables
j = 1
univ3 = list()
for(i in c(5, 6, 3, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[10]
  univ3[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 10], color = DATASET[, 2])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle('엔진스피드별')
  j = j + 1
}


grid.arrange(univ3[[1]], univ3[[2]], univ3[[3]], univ3[[4]], nrow = 2, ncol = 2)




## --------------------------------------------------------------------------------------------------------

result = vector(length = 12)
for(i in c(1:12)) {
  ind = ((1000 + 100*i - 30) < DATASET$엔진스피드) & (DATASET$엔진스피드 < (1000 + 100*i + 30))
  D1 = na.omit(DATASET[ind, ])
  result[i] = mean(D1[, 10])
}
sq = seq(1100, 2200, by = 100)
df = as.data.frame(cbind(sq, result))
names(df) = c('x1', 'y1')
b <- ggplot(df, aes(x = x1, y = y1)) +
  geom_point() +
  geom_line()  +
  labs(x = names(D1)[2]) +
  labs(y = names(D1)[10])

grid.arrange(a, b, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------
fit1_vc6 = gam(NO2배출량 ~ s(엔진스피드) + s(엔진스피드, by = 엔진부하), data = DATASET)
summary(fit1_vc6)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit1_vc6, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
fitted1v = pvc1$fit[, 1]
fitted1se = pvc1$se.fit[, 1]
fitted1.up95 = fitted1v + 1.96 * fitted1se
fitted1.lw95 = fitted1v - 1.96 * fitted1se
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue') +
  labs(x = '엔진스피드') +
  labs(y = 'beta0') +
  geom_vline(xintercept = 1560, color = 'blue', alpha = 0.5) +
  geom_vline(xintercept = 1890, color = 'blue', alpha = 0.5) +
  geom_vline(xintercept = 1220, color = 'blue', alpha = 0.5) +
  geom_vline(xintercept = 1370, color = 'red', alpha = 0.5) +
  geom_vline(xintercept = 1750, color = 'red', alpha = 0.5) 

fitted2v = pvc1$fit[, 2]
fitted2se = pvc1$se.fit[, 2]
fitted2.up95 = fitted2v + 1.96 * fitted2se
fitted2.lw95 = fitted2v - 1.96 * fitted2se
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진스피드') +
  labs(y = 'beta1') +
  geom_vline(xintercept = 1560, color = 'red', alpha = 0.5) +
  geom_vline(xintercept = 1890, color = 'red', alpha = 0.5) +
  geom_vline(xintercept = 1220, color = 'red', alpha = 0.5) +
  geom_vline(xintercept = 1370, color = 'blue', alpha = 0.5) +
  geom_vline(xintercept = 1750, color = 'blue', alpha = 0.5) 

grid.arrange(a1, a2, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 100)
pvc1 = predict(fit1_vc6, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
coef_vc1 = pvc1$fit
intceptv =  coef(fit1_vc6)[1]



## ---- echo = FALSE---------------------------------------------------------------------------------------
l = list()
k1 = list()
for(i in c(1:12)) {
  ind = ((1000 + 100*i - 15) < DATASET$엔진스피드) & (DATASET$엔진스피드 < (1000 + 100*i + 15))
  D1 = DATASET[ind, ]
  l[[i]] = lm(NO2배출량 ~ 엔진부하, data = D1)
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 12))
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:12)) {
  legend1[i,] = c(30, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 30, i)  
}

legend2 = data.frame(matrix(ncol = 3, nrow = 12))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:12)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] +intceptv , slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(35, coef_vc1[i, ][1] + intceptv  + coef_vc1[i, ][2]*35, i)
}


## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 3], y = DATASET[, 10], color = DATASET[,2])) +
  geom_point(size = 0.5)  + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]] + k1[[8]] + k1[[9]] + k1[[10]] + k1[[11]] + k1[[12]] + k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]] + k2[[8]] + k2[[9]] + k2[[10]] + k2[[11]] + k2[[12]] + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label), color = 'blue') + labs(x = names(DATASET[3])) +  labs(y = names(DATASET[10]))

  


## --------------------------------------------------------------------------------------------------------
fit2_vc6 = gam(NO2배출량 ~ 엔진스피드 + 엔진부하 + 엔진스피드*엔진부하, data = DATASET)
summary(fit2_vc6)



## --------------------------------------------------------------------------------------------------------
r0 = coef(fit2_vc6)[1]
r1 = coef(fit2_vc6)[2]
d0 = coef(fit2_vc6)[3]
d1 = coef(fit2_vc6)[4]
c = coef(fit1_vc6)[1]

sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit1_vc6, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진스피드')  +
  labs(y = 'beta1')
c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진스피드')   +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
#Exhmf, Exhtemp, Engload <- independent variables
j = 1
univ3 = list()
for(i in c(5, 6, 3, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[11]
  univ3[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 11], color = DATASET[, 2])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle('엔진스피드별') +
    geom_smooth(method = 'lm')
  j = j + 1
}


grid.arrange(univ3[[1]], univ3[[2]], univ3[[3]], univ3[[4]], nrow = 2, ncol = 2)



## --------------------------------------------------------------------------------------------------------
fit1_vc7 = gam(O2배출량 ~ s(엔진스피드) + s(엔진스피드, by = 엔진부하),  data = DATASET)
summary(fit1_vc7)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit1_vc7, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
fitted1v = pvc1$fit[, 1]
fitted1se = pvc1$se.fit[, 1]
fitted1.up95 = fitted1v + 1.96 * fitted1se
fitted1.lw95 = fitted1v - 1.96 * fitted1se
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue') +
  labs(x = '엔진스피드') +
  labs(y = 'beta0')

fitted2v = pvc1$fit[, 2]
fitted2se = pvc1$se.fit[, 2]
fitted2.up95 = fitted2v + 1.96 * fitted2se
fitted2.lw95 = fitted2v - 1.96 * fitted2se
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진스피드') +
  labs(y = 'beta1') +
  geom_vline(xintercept = 2000, color = 'red', alpha = 0.5)

grid.arrange(a1, a2, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(1100, 2200, 100)
pvc1 = predict(fit1_vc7, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + 28.0481, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')



## ---- echo = FALSE---------------------------------------------------------------------------------------
l = list()
k1 = list()
for(i in c(1:12)) {
  ind = ((1000 + 100*i - 15) < DATASET$엔진스피드) & (DATASET$엔진스피드 < (1000 + 100*i + 15))
  D1 = DATASET[ind, ]
  l[[i]] = lm(O2배출량 ~ 엔진부하, data = D1)
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 12))
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:12)) {
  legend1[i,] = c(95, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 95, i)  
}

legend2 = data.frame(matrix(ncol = 3, nrow = 12))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:12)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] + 28.0481, slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(100, coef_vc1[i, ][1] + 28.0481 + coef_vc1[i, ][2]*100, i)
}


## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 3], y = DATASET[, 11], color = DATASET[, 2])) +
  geom_point(size = 0.5)  + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]] + k1[[8]] + k1[[9]] + k1[[10]] + k1[[11]] + k1[[12]] + k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]] + k2[[8]] + k2[[9]] + k2[[10]] + k2[[11]] + k2[[12]] + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label), color = 'blue') + labs(x = names(DATASET[3])) +  labs(y = names(DATASET[11]))


## --------------------------------------------------------------------------------------------------------
fit2_vc7 = lm(O2배출량 ~ 엔진스피드 + 엔진부하 + 엔진부하:엔진스피드, data = DATASET)
summary(fit2_vc7)


## --------------------------------------------------------------------------------------------------------
r0 = coef(fit2_vc7)[1]
r1 = coef(fit2_vc7)[2]
d0 = coef(fit2_vc7)[3]
d1 = coef(fit2_vc7)[4]
c = coef(fit1_vc7)[1]

sq1 = seq(1100, 2200, 1)
pvc1 = predict(fit1_vc7, type = 'terms', se.fit = T, newdata = data.frame(엔진스피드 = sq1, intercept = 1, 엔진부하 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진스피드')  +
  labs(y = 'beta0')
c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진스피드')   +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)



## --------------------------------------------------------------------------------------------------------
fit3_vc7 = gam(O2배출량 ~ 엔진스피드 + 엔진부하,  data = DATASET)
summary(fit3_vc7)

