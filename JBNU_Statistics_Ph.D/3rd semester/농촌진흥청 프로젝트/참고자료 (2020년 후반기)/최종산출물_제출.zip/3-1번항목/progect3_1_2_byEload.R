## ----setup, include=FALSE--------------------------------------------------------------------------------
library(readxl)
library(tidyverse)
library(mgcv)
library(ggplot2)
library(gridExtra)


## ---- message = FALSE------------------------------------------------------------------------------------
DATASET = read.csv("project3.csv",check.names=FALSE)
names(DATASET) = c('NO', '엔진스피드', '엔진부하', 'fuelrate', '배기가스질량유량', '배기가스온도', 'CO2배출량', 'CO배출량', 'NO배출량', 'NO2배출량', 'O2배출량',  'CO2masskwh', 'COmasskwh', 'NOmasskwh', 'NO2masskwh', 'O2masskwh', '엔진파워', 'BSFC', 'NOX')
DATASET = as.data.frame(DATASET)


## --------------------------------------------------------------------------------------------------------
a = DATASET$NO[(DATASET$엔진스피드< 1080)]
a = na.omit(a)
length(a)
dim(DATASET)
DATASET_A = DATASET[-a,]
dim(DATASET_A)


## --------------------------------------------------------------------------------------------------------
dim(DATASET_A)
DATASET_A %>%
  filter(엔진부하 >= 31) -> DATASET_B
dim(DATASET_B)
DATASET = DATASET_B


## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
j = 1
univ1 = list()
for(i in c(3, 5, 6, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[4]
  univ1[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 4], color = DATASET[, 3])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle('엔진부하 별')  
  j = j + 1
}

grid.arrange(univ1[[1]], univ1[[2]], univ1[[3]], univ1[[4]], nrow = 2, ncol = 2)


## --------------------------------------------------------------------------------------------------------
fit3_vc1 = gam(fuelrate ~ s(엔진부하) + s(엔진부하, by = 엔진스피드), data = DATASET)
summary(fit3_vc1)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(40, 100, 0.1)
pvc1 = predict(fit3_vc1, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept  = 1, 엔진스피드 = 1))
fitted1v = pvc1$fit[, 1]
fitted1se = pvc1$se.fit[, 1]
fitted1.up95 = fitted1v + 1.96 * fitted1se
fitted1.lw95 = fitted1v - 1.96 * fitted1se
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue') +
  labs(x = '엔진부하') +
  labs(y = 'beta0')

fitted2v = pvc1$fit[, 2]
fitted2se = pvc1$se.fit[, 2]
fitted2.up95 = fitted2v + 1.96 * fitted2se
fitted2.lw95 = fitted2v - 1.96 * fitted2se
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진부하') +
  labs(y = 'beta1') 

grid.arrange(a1, a2, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(40, 100, 10)
pvc1 = predict(fit3_vc1, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit


## ---- echo = FALSE---------------------------------------------------------------------------------------
intercept_v = coef(fit3_vc1)[1]

l = list()
k1 = list()
for(i in c(1:7)) {
  ind = ((30 + 10*i - 3) < DATASET$엔진부하) & (DATASET$엔진부하 < (30 + 10*i + 3))
  D1 = DATASET[ind, ]
  l[[i]] = lm(fuelrate ~ 엔진스피드, data = D1)
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:7)) {
  legend1[i,] = c(2050, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 2050, i)  
}

legend2 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:7)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] + intercept_v, slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(2150, coef_vc1[i, ][1] + intercept_v + coef_vc1[i, ][2]*2150, i)
}



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 2], y = DATASET[, 4], color = DATASET[, 3])) +
  geom_point(size = 0.5, alpha = 0.5) + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]]  + k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]] + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'blue') + labs(x = names(DATASET[2])) +  labs(y = names(DATASET[4]))




## --------------------------------------------------------------------------------------------------------
fit5_vc1 = lm(fuelrate ~ 엔진부하 + 엔진스피드  + 엔진부하:엔진스피드, data = DATASET)
summary(fit5_vc1)


## --------------------------------------------------------------------------------------------------------
r0 = coef(fit5_vc1)[1]
r1 = coef(fit5_vc1)[2]
d0 = coef(fit5_vc1)[3]
d1 = coef(fit5_vc1)[4]
c = coef(fit3_vc1)[1]

sq1 = seq(40, 100, 0.1)
pvc1 = predict(fit3_vc1, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진부하')  +
  labs(y = 'beta0')
c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진부하')   +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
j = 1
univ2 = list()
for(i in c(4, 6, 3, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[5]
  univ2[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 5], color = DATASET[,3])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle('엔진부하 별')
  j = j + 1
}

grid.arrange(univ2[[1]], univ2[[2]], univ2[[3]], univ2[[4]], nrow = 2, ncol = 2)



## --------------------------------------------------------------------------------------------------------
fit3_vc2 = gam(배기가스질량유량 ~ s(엔진부하) + s(엔진부하, by = 엔진스피드), data = DATASET)
summary(fit3_vc2)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(40, 100, 0.1)
pvc1 = predict(fit3_vc2, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept  = 1, 엔진스피드 = 1))
fitted1v = pvc1$fit[, 1]
fitted1se = pvc1$se.fit[, 1]
fitted1.up95 = fitted1v + 1.96 * fitted1se
fitted1.lw95 = fitted1v - 1.96 * fitted1se
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue') +
  labs(x = '엔진부하') +
  labs(y = 'beta0')

fitted2v = pvc1$fit[, 2]
fitted2se = pvc1$se.fit[, 2]
fitted2.up95 = fitted2v + 1.96 * fitted2se
fitted2.lw95 = fitted2v - 1.96 * fitted2se
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진부하') +
  labs(y = 'beta1')

grid.arrange(a1, a2, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(40, 100, 10)
pvc1 = predict(fit3_vc2, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit



## ---- echo = FALSE---------------------------------------------------------------------------------------
intercept_v = coef(fit3_vc2)[1]

l = list()
k1 = list()
for(i in c(1:7)) {
  ind = ((30 + 10*i - 3) < DATASET$엔진부하) & (DATASET$엔진부하 < (30 + 10*i + 3))
  D1 = DATASET[ind, ]
  l[[i]] = lm(배기가스질량유량 ~ 엔진스피드, data = D1)
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:7)) {
  legend1[i,] = c(2050, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 2050, i)  
}

legend2 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:7)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] + intercept_v, slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(2150, coef_vc1[i, ][1] + intercept_v + coef_vc1[i, ][2]*2150, i)
}



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 2], y = DATASET[, 5], color = DATASET[, 3])) +
  geom_point(size = 0.5, alpha = 0.5) + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]] +  k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]]  + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'blue') + labs(x = names(DATASET[2])) +  labs(y = names(DATASET[5]))



## --------------------------------------------------------------------------------------------------------
fit5_vc2 = lm(배기가스질량유량 ~ 엔진부하 + 엔진스피드  + 엔진부하:엔진스피드, data = DATASET)
summary(fit5_vc2)


## --------------------------------------------------------------------------------------------------------
r0 = coef(fit5_vc2)[1]
r1 = coef(fit5_vc2)[2]
d0 = coef(fit5_vc2)[3]
d1 = coef(fit5_vc2)[4]
c = coef(fit3_vc2)[1]

sq1 = seq(40, 100, 0.1)
pvc1 = predict(fit3_vc2, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진부하')  +
  labs(y = 'beta0')
c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진부하')   +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)



## --------------------------------------------------------------------------------------------------------
fit4_vc2 = gam(배기가스질량유량 ~ 엔진부하 + 엔진스피드, data = DATASET)
summary(fit4_vc2)


## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
#Exhmf, Exhtemp, Engload <- independent variables
j = 1
univ3 = list()
for(i in c(5, 6, 3, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[7]
  univ3[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 7], color = DATASET[, 3])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle("엔진부하별")
  j = j + 1
}


grid.arrange(univ3[[1]], univ3[[2]], univ3[[3]], univ3[[4]], nrow = 2, ncol = 2)


## --------------------------------------------------------------------------------------------------------
fit3_vc3 = gam(CO2배출량 ~ s(엔진부하) + s(엔진부하, by = 엔진스피드), data = DATASET)
summary(fit3_vc3)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(40, 100, 0.1)
pvc1 = predict(fit3_vc3, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept  = 1, 엔진스피드 = 1))
fitted1v = pvc1$fit[, 1]
fitted1se = pvc1$se.fit[, 1]
fitted1.up95 = fitted1v + 1.96 * fitted1se
fitted1.lw95 = fitted1v - 1.96 * fitted1se
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue') +
  labs(x = '엔진부하') +
  labs(y = 'beta0')

fitted2v = pvc1$fit[, 2]
fitted2se = pvc1$se.fit[, 2]
fitted2.up95 = fitted2v + 1.96 * fitted2se
fitted2.lw95 = fitted2v - 1.96 * fitted2se
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진부하') +
  labs(y = 'beta1')

grid.arrange(a1, a2, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(40, 100, 10)
pvc1 = predict(fit3_vc3, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit


## ---- echo = FALSE---------------------------------------------------------------------------------------
intercept_v = coef(fit3_vc3)[1]

l = list()
k1 = list()
for(i in c(1:7)) {
  ind = ((30 + 10*i - 3) < DATASET$엔진부하) & (DATASET$엔진부하 < (30 + 10*i + 3))
  D1 = DATASET[ind, ]
  l[[i]] = lm(CO2배출량 ~ 엔진스피드, data = D1)
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:7)) {
  legend1[i,] = c(2050, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 2050, i)  
}

legend2 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:7)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] + intercept_v, slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(2150, coef_vc1[i, ][1] + intercept_v + coef_vc1[i, ][2]*2150, i)
}



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 2], y = DATASET[, 7], color = DATASET[, 3])) +
  geom_point(size = 0.5, alpha = 0.5) + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]]   + k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]] + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'blue') + labs(x = names(DATASET[2])) +  labs(y = names(DATASET[7]))



## --------------------------------------------------------------------------------------------------------
fit5_vc3 = lm(CO2배출량 ~ 엔진부하 + 엔진스피드  + 엔진부하:엔진스피드, data = DATASET)
summary(fit5_vc3)


## --------------------------------------------------------------------------------------------------------
r0 = coef(fit5_vc3)[1]
r1 = coef(fit5_vc3)[2]
d0 = coef(fit5_vc3)[3]
d1 = coef(fit5_vc3)[4]
c = coef(fit3_vc3)[1]

sq1 = seq(40, 100, 0.1)
pvc1 = predict(fit3_vc3, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진부하')  +
  labs(y = 'beta1')
c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진부하')   +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
j = 1
univ3 = list()
for(i in c(5, 6, 3, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[8]
  univ3[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 8], color = DATASET[, 3])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname)+
    ggtitle('엔진부하 별')
  j = j + 1
}

grid.arrange(univ3[[1]], univ3[[2]], univ3[[3]], univ3[[4]], nrow = 2, ncol = 2)


## --------------------------------------------------------------------------------------------------------
fit3_vc4 = gam(CO배출량 ~ s(엔진부하) + s(엔진부하, by = 엔진스피드) , data = DATASET)
summary(fit3_vc4)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(40, 100, 0.1)
pvc1 = predict(fit3_vc4, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, 엔진부하  = 1, 엔진스피드 = 1))
fitted1v = pvc1$fit[, 1]
fitted1se = pvc1$se.fit[, 1]
fitted1.up95 = fitted1v + 1.96 * fitted1se
fitted1.lw95 = fitted1v - 1.96 * fitted1se
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue') +
  labs(x = '엔진부하') +
  labs(y = 'beta0')

fitted2v = pvc1$fit[, 2]
fitted2se = pvc1$se.fit[, 2]
fitted2.up95 = fitted2v + 1.96 * fitted2se
fitted2.lw95 = fitted2v - 1.96 * fitted2se
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진부하') +
  labs(y = 'beta1')

grid.arrange(a1, a2, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(40, 100, 10)
pvc1 = predict(fit3_vc4, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit


## ---- echo = FALSE---------------------------------------------------------------------------------------
intercept_v = coef(fit3_vc4)[1]

l = list()
k1 = list()
for(i in c(1:7)) {
  ind = ((30 + 10*i - 3) < DATASET$엔진부하) & (DATASET$엔진부하 < (30 + 10*i + 3))
  D1 = DATASET[ind, ]
  l[[i]] = lm(CO배출량 ~ 엔진스피드, data = D1)
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:7)) {
  legend1[i,] = c(2050, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 2050, i)  
}

legend2 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:7)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] + intercept_v, slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(2150, coef_vc1[i, ][1] + intercept_v + coef_vc1[i, ][2]*2150, i)
}



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 2], y = DATASET[, 8], color = DATASET[, 3])) +
  geom_point(size = 0.5, alpha = 0.5) + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]]  + k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]] + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'blue') + labs(x = names(DATASET[2])) +  labs(y = names(DATASET[8]))



## --------------------------------------------------------------------------------------------------------
fit5_vc4 = lm(CO배출량 ~ 엔진부하 + 엔진스피드  + 엔진부하:엔진스피드, data = DATASET)
summary(fit5_vc4)


## --------------------------------------------------------------------------------------------------------
r0 = coef(fit5_vc4)[1]
r1 = coef(fit5_vc4)[2]
d0 = coef(fit5_vc4)[3]
d1 = coef(fit5_vc4)[4]
c = coef(fit3_vc4)[1]

sq1 = seq(40, 100, 0.1)
pvc1 = predict(fit3_vc4, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진부하')  +
  labs(y = 'beta0')
c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진부하')   +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
j = 1
univ3 = list()
for(i in c(5, 6, 3, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[9]
  univ3[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 9], color = DATASET[, 3])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle('엔진부하 별') 
  j = j + 1
}


grid.arrange(univ3[[1]], univ3[[2]], univ3[[3]], univ3[[4]], nrow = 2, ncol = 2)


## ---- message = FALSE, warning = FALSE-------------------------------------------------------------------
result = vector(length = 7)
for(i in c(1:7)) {
  ind = ((30 + 10*i - 3) < DATASET$엔진부하) & (DATASET$엔진부하 < (30 + 10*i + 3))
  D1 = na.omit(DATASET[ind, ])
  result[i] = mean(D1[, 9])
}
sq = seq(40, 100, by = 10)
df = as.data.frame(cbind(sq, result))
names(df) = c('x1', 'y1')
a <- ggplot(df, aes(x = x1, y = y1)) +
  geom_point() +
  geom_line() +
  labs(x = names(D1)[3]) +
  labs(y = names(D1)[9])
a


## --------------------------------------------------------------------------------------------------------
fit3_vc5 = gam(NO배출량 ~ s(엔진부하) + s(엔진부하, by = 엔진스피드), data = DATASET)
summary(fit3_vc5)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(40, 100, 0.1)
pvc1 = predict(fit3_vc5, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept  = 1, 엔진스피드 = 1))
fitted1v = pvc1$fit[, 1]
fitted1se = pvc1$se.fit[, 1]
fitted1.up95 = fitted1v + 1.96 * fitted1se
fitted1.lw95 = fitted1v - 1.96 * fitted1se
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1, color = 'blue') +
  labs(x = '엔진부하') +
  labs(y = 'beta0')

fitted2v = pvc1$fit[, 2]
fitted2se = pvc1$se.fit[, 2]
fitted2.up95 = fitted2v + 1.96 * fitted2se
fitted2.lw95 = fitted2v - 1.96 * fitted2se
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진부하') +
  labs(y = 'beta1')

grid.arrange(a1, a2, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------

sq1 = seq(40, 100, 10)
pvc1 = predict(fit3_vc5, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit


## ---- echo = FALSE---------------------------------------------------------------------------------------
intercept_v = coef(fit3_vc5)[1]

l = list()
k1 = list()
for(i in c(1:7)) {
  ind = ((30 + 10*i - 3) < DATASET$엔진부하) & (DATASET$엔진부하 < (30 + 10*i + 3))
  D1 = DATASET[ind, ]
  l[[i]] = lm(NO배출량 ~ 엔진스피드, data = D1)
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:7)) {
  legend1[i,] = c(2050, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 2050, i)  
}

legend2 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:7)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] + intercept_v, slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(2150, coef_vc1[i, ][1] + intercept_v + coef_vc1[i, ][2]*2150, i)
}



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 2], y = DATASET[, 9], color = DATASET[, 3])) +
  geom_point(size = 0.5, alpha = 0.5) + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]] +  k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]]  + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'blue') + labs(x = names(DATASET[2])) +  labs(y = names(DATASET[9]))



## --------------------------------------------------------------------------------------------------------
fit5_vc5 = lm(NO배출량 ~ 엔진부하 + 엔진스피드 + 엔진부하:엔진스피드, data = DATASET)
summary(fit5_vc5)


## --------------------------------------------------------------------------------------------------------
r0 = coef(fit5_vc5)[1]
r1 = coef(fit5_vc5)[2]
d0 = coef(fit5_vc5)[3]
d1 = coef(fit5_vc5)[4]
c = coef(fit3_vc5)[1]

sq1 = seq(40, 100, 0.1)
pvc1 = predict(fit3_vc5, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진부하')  +
  labs(y = 'beta0')
c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진부하')   +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
#Exhmf, Exhtemp, Engload <- independent variables
j = 1
univ3 = list()
for(i in c(5, 6, 3, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[10]
  univ3[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 10], color = DATASET[, 3])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle('엔진부하 별') 
  j = j + 1
}

grid.arrange(univ3[[1]], univ3[[2]], univ3[[3]], univ3[[4]], nrow = 2, ncol = 2)


## ---- message = FALSE, warning = FALSE-------------------------------------------------------------------
result = vector(length = 7)
for(i in c(1:7)) {
  ind = ((30 + 10*i - 3) < DATASET$엔진부하) & (DATASET$엔진부하 < (30 + 10*i + 3))
  D1 = na.omit(DATASET[ind, ])
  result[i] = mean(D1[, 10])
}
sq = seq(40, 100, by = 10)
df = as.data.frame(cbind(sq, result))
names(df) = c('x1', 'y1')
b <- ggplot(df, aes(x = x1, y = y1)) +
  geom_point() +
  geom_line() +
  labs(x = names(D1)[3]) +
  labs(y = names(D1)[10])
grid.arrange(a, b, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------
fit3_vc6 = gam(NO2배출량 ~ s(엔진부하) + s(엔진부하, by = 엔진스피드), data = DATASET)
summary(fit3_vc6)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(40, 100, 0.1)
pvc1 = predict(fit3_vc6, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept  = 1, 엔진스피드 = 1))
fitted1v = pvc1$fit[, 1]
fitted1se = pvc1$se.fit[, 1]
fitted1.up95 = fitted1v + 1.96 * fitted1se
fitted1.lw95 = fitted1v - 1.96 * fitted1se
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue') +
  labs(x = '엔진부하') +
  labs(y = 'beta0')

fitted2v = pvc1$fit[, 2]
fitted2se = pvc1$se.fit[, 2]
fitted2.up95 = fitted2v + 1.96 * fitted2se
fitted2.lw95 = fitted2v - 1.96 * fitted2se
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진부하') +
  labs(y = 'beta1')

grid.arrange(a1, a2, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(40, 100, 10)
pvc1 = predict(fit3_vc6, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit


## ---- echo = FALSE---------------------------------------------------------------------------------------
intercept_v = coef(fit3_vc6)[1]

l = list()
k1 = list()
for(i in c(1:7)) {
  ind = ((30 + 10*i - 3) < DATASET$엔진부하) & (DATASET$엔진부하 < (30 + 10*i + 3))
  D1 = DATASET[ind, ]
  l[[i]] = lm(NO2배출량 ~ 엔진스피드, data = D1)
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:7)) {
  legend1[i,] = c(2050, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 2050, i)  
}

legend2 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:7)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] + intercept_v, slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(2150, coef_vc1[i, ][1] + intercept_v + coef_vc1[i, ][2]*2150, i)
}



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 2], y = DATASET[,10], color = DATASET[, 9])) +
  geom_point(size = 0.5, alpha = 0.5) + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]]  + k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]] + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'blue') + labs(x = names(DATASET[2])) +  labs(y = names(DATASET[10]))



## --------------------------------------------------------------------------------------------------------
fit5_vc6 = lm(NO2배출량 ~ 엔진부하 + 엔진스피드  + 엔진부하:엔진스피드, data = DATASET)
summary(fit5_vc6)


## --------------------------------------------------------------------------------------------------------
r0 = coef(fit5_vc6)[1]
r1 = coef(fit5_vc6)[2]
d0 = coef(fit5_vc6)[3]
d1 = coef(fit5_vc6)[4]
c = coef(fit3_vc6)[1]

sq1 = seq(30, 100, 0.1)
pvc1 = predict(fit3_vc6, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진부하')  +
  labs(y = 'beta0')
c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진부하')   +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
#Exhmf, Exhtemp, Engload <- independent variables
j = 1
univ3 = list()
for(i in c(5, 6, 3, 2)) {
  xname = names(DATASET)[i]
  yname = names(DATASET)[11]
  univ3[[j]] = ggplot(DATASET, aes_(x = DATASET[, i], y = DATASET[, 11], color = DATASET[, 3])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle('엔진부하 별') 
  j = j + 1
}

grid.arrange(univ3[[1]], univ3[[2]], univ3[[3]], univ3[[4]], nrow = 2, ncol = 2)


## --------------------------------------------------------------------------------------------------------
fit3_vc7 = gam(O2배출량 ~ s(엔진부하) + s(엔진부하, by = 엔진스피드), data = DATASET)
summary(fit3_vc7)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(40, 100, 0.1)
pvc1 = predict(fit3_vc7, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept  = 1, 엔진스피드 = 1))
fitted1v = pvc1$fit[, 1]
fitted1se = pvc1$se.fit[, 1]
fitted1.up95 = fitted1v + 1.96 * fitted1se
fitted1.lw95 = fitted1v - 1.96 * fitted1se
d = as.data.frame(cbind(sq1, fitted1v, fitted1.up95, fitted1.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a1 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue') +
  labs(x = '엔진부하') +
  labs(y = 'beta0')

fitted2v = pvc1$fit[, 2]
fitted2se = pvc1$se.fit[, 2]
fitted2.up95 = fitted2v + 1.96 * fitted2se
fitted2.lw95 = fitted2v - 1.96 * fitted2se
d = as.data.frame(cbind(sq1, fitted2v, fitted2.up95, fitted2.lw95))
colnames(d) = c('x', 'y', 'yup', 'ylw')
a2 <- ggplot(d, aes(x = x, y = y)) +
  geom_point(aes(x = x, y = y), size = 0.1) +
  geom_point(aes(x = x, y = yup), size = 0.1, alpha = 0.1, color = 'blue') +
  geom_point(aes(x = x, y = ylw), size = 0.1, alpha = 0.1,color = 'blue')+
  labs(x = '엔진부하') +
  labs(y = 'beta1')

grid.arrange(a1, a2, nrow = 1, ncol = 2)


## --------------------------------------------------------------------------------------------------------
sq1 = seq(40, 100, 10)
pvc1 = predict(fit3_vc7, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit


## ---- echo = FALSE---------------------------------------------------------------------------------------
intercept_v = coef(fit3_vc7)[1]

l = list()
k1 = list()
for(i in c(1:7)) {
  ind = ((30 + 10*i - 3) < DATASET$엔진부하) & (DATASET$엔진부하 < (30 + 10*i + 3))
  D1 = DATASET[ind, ]
  l[[i]] = lm(O2배출량 ~ 엔진스피드, data = D1)
  k1[[i]] <-  geom_abline(intercept = l[[i]]$coefficients[1], slope = l[[i]]$coefficients[2], color = 'red', alpha = 0.5) 
}

legend1 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend1) = c("x_pos" , "y_pos" , "label")
for(i in c(1:7)) {
  legend1[i,] = c(2050, l[[i]]$coefficients[1] + l[[i]]$coefficients[2] * 2050, i)  
}

legend2 = data.frame(matrix(ncol = 3, nrow = 8))
colnames(legend2) = c("x_pos" , "y_pos" , "label")
k2 = list()
for(i in c(1:7)) {
  k2[[i]] <- geom_abline(intercept = coef_vc1[i, ][1] + intercept_v, slope = coef_vc1[i, ][2], color = 'blue', alpha = 0.7)
  legend2[i, ] = c(2150, coef_vc1[i, ][1] + intercept_v + coef_vc1[i, ][2]*2150, i)
}



## ---- warning = FALSE, message = FALSE-------------------------------------------------------------------
ggplot(DATASET, aes_(x = DATASET[, 2], y = DATASET[, 11], color = DATASET[, 3])) +
  geom_point(size = 0.5, alpha = 0.5) + k1[[1]] + k1[[2]] + k1[[3]] + k1[[4]] + k1[[5]] + k1[[6]] + k1[[7]]   + k2[[1]] + k2[[2]] + k2[[3]] + k2[[4]] + k2[[5]] + k2[[6]] + k2[[7]] + geom_text(data = legend1, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'red') + geom_text(data = legend2, aes(x = x_pos, y = y_pos, label = label, size = 10), color = 'blue') + labs(x = names(DATASET[2])) +  labs(y = names(DATASET[11]))



## --------------------------------------------------------------------------------------------------------
fit5_vc7 = lm(O2배출량 ~ 엔진부하 + 엔진스피드  + 엔진부하:엔진스피드, data = DATASET)
summary(fit5_vc7)


## --------------------------------------------------------------------------------------------------------
r0 = coef(fit5_vc7)[1]
r1 = coef(fit5_vc7)[2]
d0 = coef(fit5_vc7)[3]
d1 = coef(fit5_vc7)[4]
c = coef(fit3_vc7)[1]

sq1 = seq(40, 100, 0.1)
pvc1 = predict(fit3_vc7, type = 'terms', se.fit = T, newdata = data.frame(엔진부하 = sq1, intercept = 1, 엔진스피드 = 1))
coef_vc1 = pvc1$fit
d_plot = as.data.frame(cbind(sq1, coef_vc1[,1] + c, coef_vc1[, 2]))
colnames(d_plot) = c('x','y1', 'y2')


c1 <- ggplot(d_plot, aes(x = x, y = y1)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = r0, slope = r1) +
  labs(x = '엔진부하')  +
  labs(y = 'beta1')
c2 <- ggplot(d_plot, aes(x = x, y = y2)) +
  geom_point(size = 0.1, alpha = 0.5) +
  geom_abline(intercept = d0, slope = d1)+
  labs(x = '엔진부하')   +
  labs(y = 'beta1')
  
grid.arrange(c1, c2, nrow = 1, ncol = 2)


