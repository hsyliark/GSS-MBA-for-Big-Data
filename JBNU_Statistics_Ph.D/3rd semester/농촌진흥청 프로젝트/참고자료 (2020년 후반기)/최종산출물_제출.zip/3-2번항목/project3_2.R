## ----setup, include=FALSE--------------------------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----packages, ehco=FALSE,warning = FALSE, message = FALSE-----------------------------------------------
library(ggplot2) # ggplot을 활용한 시각화를 위한 package
library(gridExtra) # ggplot 여러개 동시에 보여주기 위한 package
library(mgcv) # GAM 을 위한 package


## ----data------------------------------------------------------------------------------------------------
data<-read.csv("project3_5data.csv",check.names=FALSE) #"project3_5data.csv"를 불러와서 data라는 객체에 저장.


## ----data summary----------------------------------------------------------------------------------------
summary(data)


## ----data plot,fig.width = 100, fig.height = 100---------------------------------------------------------
pairs(data,cex.labels = 15)


## ----co2univar1------------------------------------------------------------------------------------------
j = 1
univ1 = list()
for(i in 1:2) {
  xname = names(data)[i]
  yname = names(data)[3]
  univ1[[j]] = ggplot(data, aes_(x = data[, i], y = data[, 3], color = data[, 3-i])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle(paste0(names(data)[3-i]," 별"))  
  j = j + 1
}

grid.arrange(univ1[[1]], univ1[[2]], nrow = 1, ncol = 2)


## ----co2varing1------------------------------------------------------------------------------------------
fit1 = gam(CO2masskwh ~ s(엔진스피드) + s(엔진스피드, by = 엔진부하),  data = data)
summary(fit1)


## ----co2varing1plot--------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit1,select = 1)
plot.gam(fit1,select = 2,ylim = c(-10,0))
vis.gam(fit1,plot.type="contour", too.far=0.1)


## ----co2varing2------------------------------------------------------------------------------------------
fit2 = gam(CO2masskwh ~ s(엔진부하) + s(엔진부하, by = 엔진스피드),  data = data)
summary(fit2)


## ----co2varing2plot--------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit2,select = 1)
plot.gam(fit2,select = 2,ylim = c(-0.5,0.5))
vis.gam(fit2,plot.type="contour", too.far=0.1)


## ----co2varing3------------------------------------------------------------------------------------------
fit3 = gam(CO2masskwh ~ s(엔진부하) + s(엔진스피드),  data = data)
summary(fit3)


## ----co2varing3plot--------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit3,select = 1)
plot.gam(fit3,select = 2,ylim = c(-100,100))
vis.gam(fit3,plot.type="contour", too.far=0.1)


## ----r2 co2----------------------------------------------------------------------------------------------
fit0 = lm(CO2masskwh ~ 엔진부하*엔진스피드, data = data)
data.frame("교호작용 model"=summary(fit0)$r.sq,"엔진스피드 VC model"=summary(fit1)$r.sq,"엔진부하 VC model"=summary(fit2)$r.sq,"GAM"=summary(fit3)$r.sq)


## ----modelco2--------------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit3,select = 1)
plot.gam(fit3,select = 2,ylim = c(-100,100))


## ----modelco2vc------------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit2,select = 1)
plot.gam(fit2,select = 2,ylim = c(-0.5,0.5))


## ----counivar1-------------------------------------------------------------------------------------------
j = 1
univ1 = list()
for(i in 1:2) {
  xname = names(data)[i]
  yname = names(data)[4]
  univ1[[j]] = ggplot(data, aes_(x = data[, i], y = data[, 4], color = data[, 3-i])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle(paste0(names(data)[3-i]," 별"))  
  j = j + 1
}

grid.arrange(univ1[[1]], univ1[[2]], nrow = 1, ncol = 2)


## ----covaring1-------------------------------------------------------------------------------------------
fit1 = gam(COmasskwh ~ s(엔진스피드) + s(엔진스피드, by = 엔진부하),  data = data)
summary(fit1)


## ----covaring1plot---------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit1,select = 1)
plot.gam(fit1,select = 2,ylim = c(-0.5,0.5))
vis.gam(fit1,plot.type="contour", too.far=0.1)


## ----covaring2-------------------------------------------------------------------------------------------
fit2 = gam(COmasskwh ~ s(엔진부하) + s(엔진부하, by = 엔진스피드),  data = data)
summary(fit2)


## ----covaring2plot---------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit2,select = 1)
plot.gam(fit2,select = 2,ylim = c(-0.1,0.1))
vis.gam(fit2,plot.type="contour", too.far=0.1)


## ----covaring3-------------------------------------------------------------------------------------------
fit3 = gam(COmasskwh ~ s(엔진부하) + s(엔진스피드),  data = data)
summary(fit3)


## ----covaring3plot---------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit3,select = 1)
plot.gam(fit3,select = 2,ylim = c(-2,4))
vis.gam(fit3,plot.type="contour", too.far=0.1)


## ----r2 co-----------------------------------------------------------------------------------------------
fit0 = lm(COmasskwh ~ 엔진부하*엔진스피드, data = data)
data.frame("교호작용 model"=summary(fit0)$r.sq,"엔진스피드 VC model"=summary(fit1)$r.sq,"엔진부하 VC model"=summary(fit2)$r.sq,"GAM"=summary(fit3)$r.sq)


## ----modelco---------------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit1,select = 1)
plot.gam(fit1,select = 2,ylim = c(-0.5,0.5))


## ----nounivar1-------------------------------------------------------------------------------------------
j = 1
univ1 = list()
for(i in 1:2) {
  xname = names(data)[i]
  yname = names(data)[5]
  univ1[[j]] = ggplot(data, aes_(x = data[, i], y = data[, 5], color = data[, 3-i])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle(paste0(names(data)[3-i]," 별"))  
  j = j + 1
}

grid.arrange(univ1[[1]], univ1[[2]], nrow = 1, ncol = 2)


## ----novaring1-------------------------------------------------------------------------------------------
fit1 = gam(NOmasskwh ~ s(엔진스피드) + s(엔진스피드, by = 엔진부하),  data = data)
summary(fit1)


## ----novaring1plot---------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit1,select = 1)
plot.gam(fit1,select = 2,ylim = c(-0.1,0.1))
vis.gam(fit1,plot.type="contour", too.far=0.1)


## ----novaring2-------------------------------------------------------------------------------------------
fit2 = gam(NOmasskwh ~ s(엔진부하) + s(엔진부하, by = 엔진스피드),  data = data)
summary(fit2)


## ----novaring2plot---------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit2,select = 1)
plot.gam(fit2,select = 2,ylim = c(-0.1,0.1))
vis.gam(fit2,plot.type="contour", too.far=0.1)


## ----novaring3-------------------------------------------------------------------------------------------
fit3 = gam(NOmasskwh ~ s(엔진부하) + s(엔진스피드),  data = data)
summary(fit3)


## ----novaring3plot---------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit3,select = 1)
plot.gam(fit3,select = 2,ylim = c(-4,2))
vis.gam(fit3,plot.type="contour", too.far=0.1)


## ----r2 no-----------------------------------------------------------------------------------------------
fit0 = lm(NOmasskwh ~ 엔진부하*엔진스피드, data = data)
data.frame("교호작용 model"=summary(fit0)$r.sq,"엔진스피드 VC model"=summary(fit1)$r.sq,"엔진부하 VC model"=summary(fit2)$r.sq,"GAM"=summary(fit3)$r.sq)


## ----modelno---------------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit1,select = 1)
plot.gam(fit1,select = 2,ylim = c(-0.1,0.1))


## ----no2univar1------------------------------------------------------------------------------------------
j = 1
univ1 = list()
for(i in 1:2) {
  xname = names(data)[i]
  yname = names(data)[6]
  univ1[[j]] = ggplot(data, aes_(x = data[, i], y = data[, 6], color = data[, 3-i])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle(paste0(names(data)[3-i]," 별"))  
  j = j + 1
}

grid.arrange(univ1[[1]], univ1[[2]], nrow = 1, ncol = 2)


## ----no2varing1------------------------------------------------------------------------------------------
fit1 = gam(NO2masskwh ~ s(엔진스피드) + s(엔진스피드, by = 엔진부하),  data = data)
summary(fit1)


## ----no2varing1plot--------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit1,select = 1)
plot.gam(fit1,select = 2,ylim = c(-0.2,0.2))
vis.gam(fit1,plot.type="contour", too.far=0.1)


## ----no2varing2------------------------------------------------------------------------------------------
fit2 = gam(NO2masskwh ~ s(엔진부하) + s(엔진부하, by = 엔진스피드),  data = data)
summary(fit2)


## ----no2varing2plot--------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit2,select = 1)
plot.gam(fit2,select = 2,ylim = c(-0.1,0.1))
vis.gam(fit2,plot.type="contour", too.far=0.1)


## ----no2varing3------------------------------------------------------------------------------------------
fit3 = gam(NO2masskwh ~ s(엔진부하) + s(엔진스피드),  data = data)
summary(fit3)


## ----no2varing3plot--------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit3,select = 1)
plot.gam(fit3,select = 2,ylim = c(-4,2))
vis.gam(fit3,plot.type="contour", too.far=0.1)


## ----r2 no2----------------------------------------------------------------------------------------------
fit0 = lm(NO2masskwh ~ 엔진부하*엔진스피드, data = data)
data.frame("교호작용 model"=summary(fit0)$r.sq,"엔진스피드 VC model"=summary(fit1)$r.sq,"엔진부하 VC model"=summary(fit2)$r.sq,"GAM"=summary(fit3)$r.sq)


## ----modelno2--------------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit1,select = 1)
plot.gam(fit1,select = 2,ylim = c(-0.2,0.2))


## ----o2univar1-------------------------------------------------------------------------------------------
j = 1
univ1 = list()
for(i in 1:2) {
  xname = names(data)[i]
  yname = names(data)[7]
  univ1[[j]] = ggplot(data, aes_(x = data[, i], y = data[, 7], color = data[, 3-i])) +
    geom_point() +
    labs(x = xname) +
    labs(y = yname) +
    ggtitle(paste0(names(data)[3-i]," 별"))  
  j = j + 1
}

grid.arrange(univ1[[1]], univ1[[2]], nrow = 1, ncol = 2)


## ----o2varing1-------------------------------------------------------------------------------------------
fit1 = gam(O2masskwh ~ s(엔진스피드) + s(엔진스피드, by = 엔진부하),  data = data)
summary(fit1)


## ----o2varing1plot---------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit1,select = 1)
plot.gam(fit1,select = 2,ylim = c(-40,0))
vis.gam(fit1,plot.type="contour", too.far=0.1)


## ----o2varing2-------------------------------------------------------------------------------------------
fit2 = gam(O2masskwh ~ s(엔진부하) + s(엔진부하, by = 엔진스피드),  data = data)
summary(fit2)


## ----o2varing2plot---------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit2,select = 1)
plot.gam(fit2,select = 2,ylim = c(-0.5,0.5))
vis.gam(fit2,plot.type="contour", too.far=0.1)


## ----o2varing3-------------------------------------------------------------------------------------------
fit3 = gam(O2masskwh ~ s(엔진부하) + s(엔진스피드),  data = data)
summary(fit3)


## ----o2varing3plot---------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit3,select = 1)
plot.gam(fit3,select = 2,ylim = c(-100,100))
vis.gam(fit3,plot.type="contour", too.far=0.1)


## ----r2 o2-----------------------------------------------------------------------------------------------
fit0 = lm(O2masskwh ~ 엔진부하*엔진스피드, data = data)
data.frame("교호작용 model"=summary(fit0)$r.sq,"엔진스피드 VC model"=summary(fit1)$r.sq,"엔진부하 VC model"=summary(fit2)$r.sq,"GAM"=summary(fit3)$r.sq)


## ----modelo2---------------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit2,select = 1)
plot.gam(fit2,select = 2,ylim = c(-0.5,0.5))


## ----modelo2 2-------------------------------------------------------------------------------------------
par(mfrow=c(1,2))
plot.gam(fit3,select = 1)
plot.gam(fit3,select = 2,ylim = c(-100,100))

