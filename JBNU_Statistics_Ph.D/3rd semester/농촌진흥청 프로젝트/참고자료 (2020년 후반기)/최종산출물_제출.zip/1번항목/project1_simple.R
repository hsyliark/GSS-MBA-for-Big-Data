## ----setup, include=FALSE----------------------------------------------------------------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----packages, ehco=FALSE,warning = FALSE, message = FALSE-------------------------------------------------------------------------------------
# 최초 실행시 package 설치를 위해 아래의 install.packages 부분 실행
# install.packages(c("mgcv","ggplot2","gridExtra","car","leaps","gvlma","lmtest")) 

library(mgcv) # GAM 을 위한 package
library(ggplot2) # ggplot을 활용한 시각화를 위한 package
library(gridExtra) # ggplot 여러개 동시에 보여주기 위한 package
library(car) # 다중공선성 확인을 위한 vif 함수를 내장하고 있는 package
library(leaps) # 변수선택을 위해 사용하는 regsubset 함수를 내장하고 있는 package
library(gvlma) # 오차항의 가정 검정을 위한 package
library(lmtest) # dwtest 를 위한 package

#####################################################
############ 1. 데이터탐색 (EDA) ####################
#####################################################

## ----dataload----------------------------------------------------------------------------------------------------------------------------------
# 아래 데이터를 불러오려면 working derectory를 데이터 파일이 있는 폴더로 설정해 주어야 한다.
data<-read.csv("트랙터변수추가na제거.csv") #저장된 csv 파일을 읽어서 data 라는 객체로 만든다. 
datana <- na.omit(data) # data 객체에서 NA를 포함하는 행을 제거하여 datana 라는 객체로 만든다.
nrow(datana) # NA 를 제거한 데이터의 관측치 개수(행의 수)


## ----scatter plot------------------------------------------------------------------------------------------------------------------------------
plot(datana) # datana 의 산점도를 그린다.



#####################################################
############ 2. 일변량분석 (EDA) ####################
#####################################################

#####################################################
########2-1 일변량 분석 – 반응변수 : 연료소비량######
#####################################################


## ----unilm1------------------------------------------------------------------------------------------------------------------------------------
g<-list() # ggplot 여러개를 동시에 보여주기 위해 list를 만들어서 저장하려고함. 그것을 위해 빈 list 를 미리 만듬
j=1       # 그래프 저장을 위한 초기값 1
r2 <-c() # 각 독립변수마다의 r2를 for을 통해 저장하려고 하는데 그전에 저장할 빈 vector를 만듬
coef <- matrix(nrow=10,ncol=4) # model 결과들에 대한 값들을 집어넣기위해 빈 matrix 생성
for(i in c(1,2,5:12)){
y <- datana$연료소비량 # 종속변수 지정 ( 연료소비량 )
x <- datana[,i] # 독립변수 지정
df <-data.frame(x,y) # lm 을 위해 독립변수와 종속변수를 합쳐서 data frame 으로 만듬
xnam <- colnames(datana)[i] # 그래프의 x축 이름을 각 독립변수로 자동 지정
ynam <- colnames(datana)[4] # 그래프의 y축 이름을 연료소비량으로 고정 지정
ly <- lm(y~x) # simple linear model
r2[j] <- summary(ly)$adj.r.squared # 각 linear model의 r square
coef[j,] <- summary(ly)$coefficients[2,] # 각 모델들의 계수, std error , t value , p value
g[[j]]<-ggplot(df,aes(x,y))+        # ggplot 을 통한 시각화 xlab : x 축 이름. 미리 지정해놓은 xnam 활용
  xlab(xnam)+ylab(ynam)+            # ylab : y 축 이름. 미리 지정해놓은 ynam 활용
  geom_point()+                     # 점을 찍음
  geom_smooth(method="lm")          # linear model의 추정선을 그림
j=j+1                               # 그래프 저장을 위한 것
}
colnames(coef)<-c("Coefficient","Std.Error","t value","Pvalue")  # 모델 결과들이 어떤건지 알려주기위해 열이름 지정


## ----unilm1result1-----------------------------------------------------------------------------------------------------------------------------
data.frame(Univariate=colnames(datana)[c(1,2,5:12)],r2=r2,coef) # 위의 결과를 data frame 으로 만들어서 확인


## ----unilm1result2, message=FALSE--------------------------------------------------------------------------------------------------------------
grid.arrange(g[[1]],g[[2]],g[[3]],g[[4]],g[[5]],g[[6]],g[[7]],g[[8]],g[[9]],g[[10]],nrow=5,ncol=2) # ggplot


#####################################################
########2-2 일변량 분석 – 반응변수 : 엔진출력  ######
#####################################################


## ----unilm2------------------------------------------------------------------------------------------------------------------------------------
g<-list() # ggplot 여러개를 동시에 보여주기 위해 list를 만들어서 저장하려고함. 그것을 위해 빈 list 를 미리 만듬
j=1 # 그래프 저장을 위한 초기값 1
r2 <-c() # 각 독립변수마다의 r2를 for을 통해 저장하려고 하는데 그전에 저장할 빈 vector를 만듬
coef <- matrix(nrow=10,ncol=4) # model 결과들에 대한 값들을 집어넣기위해 빈 matrix 생성
for(i in c(2,4:12)){
y <- datana$엔진출력 # 종속변수 지정 ( 엔진출력 )
x <- datana[,i]  # 독립변수 지정
df <-data.frame(x,y)  # lm 을 위해 독립변수와 종속변수를 합쳐서 data frame 으로 만듬
xnam <- colnames(datana)[i] # 그래프의 x축 이름을 각 독립변수로 자동 지정
ynam <- colnames(datana)[1] # 그래프의 y축 이름을 엔진출력으로 고정 지정
ly <- lm(y~x)  # simple linear model
r2[j] <- summary(ly)$adj.r.squared  # 각 linear model의 r square
coef[j,] <- summary(ly)$coefficients[2,] # 각 모델들의 계수, std error , t value , p value 
g[[j]]<-ggplot(df,aes(x,y))+  # ggplot 을 통한 시각화 xlab : x 축 이름. 미리 지정해놓은 xnam 활용
  xlab(xnam)+ylab(ynam)+      # ylab : y 축 이름. 미리 지정해놓은 ynam 활용
  geom_point()+               # 점을 찍음
  geom_smooth(method="lm")    # linear model의 추정선을 그림
j=j+1                         # 그래프 저장을 위한 것
}
colnames(coef)<-c("Coefficient","Std.Error","t value","Pvalue")  # 모델 결과들이 어떤건지 알려주기위해 열이름 지정


## ----unilm2result1-----------------------------------------------------------------------------------------------------------------------------
data.frame(Univariate=colnames(datana)[c(2,4:12)],r2=r2,coef)  # 위의 결과를 data frame 으로 만들어서 확인


## ----unilm2result2, message=FALSE--------------------------------------------------------------------------------------------------------------
grid.arrange(g[[1]],g[[2]],g[[3]],g[[4]],g[[5]],g[[6]],g[[7]],g[[8]],g[[9]],g[[10]],nrow=5,ncol=2) # ggplot


#####################################################
########2-3 일변량 분석 – 반응변수 : 연료소비율 #####
#####################################################

## ----unilm3---------------------------------------------------------------------------------------------------------------------
g<-list() # ggplot 여러개를 동시에 보여주기 위해 list를 만들어서 저장하려고함. 그것을 위해 빈 list 를 미리 만듬
j=1 # 그래프 저장을 위한 초기값 1
r2 <-c() # 각 독립변수마다의 r2를 for을 통해 저장하려고 하는데 그전에 저장할 빈 vector를 만듬
coef <- matrix(nrow=9,ncol=4) # model 결과들에 대한 값들을 집어넣기위해 빈 matrix 생성
for(i in c(1,5:12)){
y <- datana$연료소비율 # 종속변수 지정 ( 연료소비율 )
x <- datana[,i] # 독립변수 지정
df <-data.frame(x,y) # lm 을 위해 독립변수와 종속변수를 합쳐서 data frame 으로 만듬
xnam <- colnames(datana)[i]  # 그래프의 x축 이름을 각 독립변수로 자동 지정
ynam <- colnames(datana)[3]  # 그래프의 y축 이름을 엔진출력으로 고정 지정
ly <- lm(y~x) # simple linear model
r2[j] <- summary(ly)$adj.r.squared  # 각 linear model의 r square
coef[j,] <- summary(ly)$coefficients[2,] # 각 모델들의 계수, std error , t value , p value 
g[[j]]<-ggplot(df,aes(x,y))+   # ggplot 을 통한 시각화 xlab : x 축 이름. 미리 지정해놓은 xnam 활용
  xlab(xnam)+ylab(ynam)+       # ylab : y 축 이름. 미리 지정해놓은 ynam 활용
  geom_point()+              # 점을 찍음
  geom_smooth(method="lm")   # linear model의 추정선을 그림
j=j+1                       # 그래프 저장을 위한 것
}
colnames(coef)<-c("Coefficient","Std.Error","t value","Pvalue")


## ----unilm3result1, echo=FALSE-----------------------------------------------------------------------------------------------------------------
data.frame(Univariate=colnames(datana)[c(1,5:12)],r2=r2,coef) # 모델 결과들이 어떤건지 알려주기위해 열이름 지정


## ----unilm3result2, echo=FALSE, message=FALSE--------------------------------------------------------------------------------------------------
grid.arrange(g[[1]],g[[2]],g[[3]],g[[4]],g[[5]],g[[6]],g[[7]],g[[8]],g[[9]],nrow=5,ncol=2) # ggplot


## ----car---------------------------------------------------------------------------------------------------------------------------------------
datana1 <- datana[,-3] # 코딩의 편의성을 위해 datana 에서 연료소비율을 제거한 객체 datana1 생성.
datana2 <- datana[,-c(2,4)] # 반응변수가 연료소비율 일 때 제외하는 PTO출력,연료소비량 을 제거한 객체 datana2 생성.




#####################################################
###### 3. 연료소비량을 반응변수로 하는 모형 #########
#####################################################

#####################################################
########3-1 선형 모형 적합 – 반응변수 : 연료소비량###
#####################################################


## ----outliercut--------------------------------------------------------------------------------------------------------------------------------
dd<-datana1[,c(-2,-5,-8)] # 연료소비량,엔진출력에 대한 모형 작성을 위해 PTO출력, 견인출력, 총중량을 제거하여 dd 에 저장
ddd <- dd[-77,] # 이상치를 제거한 객체 ddd 생성. 


## ----newregsubset------------------------------------------------------------------------------------------------------------------------------
regfit.full <- regsubsets(연료소비량~.,data = ddd) # regsubset
reg.summary <- summary(regfit.full)
reg.summary


## ----newregsubsetplot--------------------------------------------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(reg.summary$adjr2,xlab="Number of Variables",ylab="adjr2",type='l') # adj2에 대한 plot, xlab : x축이름, ylab : y축이름
points(which.max(reg.summary$adjr2),reg.summary$adjr2[which.max(reg.summary$adjr2)],col="red",cex=2,pch=20) # 최대 point에 붉은점
plot(reg.summary$bic,xlab="Number of Variables",ylab="bic",type='l') # bic에 대한 plot, xlab : x축이름, ylab : y축이름
points(which.min(reg.summary$bic),reg.summary$bic[which.min(reg.summary$bic)],col="blue",cex=2,pch=20) # 최소 point에 푸른점


## ----newregsubsetplot2-------------------------------------------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(regfit.full,scale="adjr2") # regsubset 의 summary를 adj2 기준으로 그린다.
plot(regfit.full,scale="bic") # regsubset 의 summary를 bic 기준으로 그린다.


## ----newlm1------------------------------------------------------------------------------------------------------------------------------------
model<- lm(연료소비량~ 엔진출력+최대토크+총배기량,data=ddd) # linear model
summary(model) # 모형 적합의 summary


## ----newerror----------------------------------------------------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(model),residuals(model),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(model),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(model),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----newerrortest------------------------------------------------------------------------------------------------------------------------------
gvlma(model) # 오차항의 기본가정 만족에 대한 검정 함수 gvlma


#####################################################
########3-2 모형 설명 ###
#####################################################

## ----finalmodel1-------------------------------------------------------------------------------------------------------------------------------
summary(model)$coefficients[,1] # 추정 계수들


#####################################################
###### 4. 엔진출력을 반응변수로 하는 모형 #########
#####################################################

#####################################################
########4-1 선형 모형 적합 – 반응변수 : 엔진출력 ###
#####################################################


## ----newregsubset2-----------------------------------------------------------------------------------------------------------------------------
regfit.full <- regsubsets(엔진출력~.,data = ddd) # regsubset
reg.summary <- summary(regfit.full)
reg.summary


## ----newregsubsetplot3-------------------------------------------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(reg.summary$adjr2,xlab="Number of Variables",ylab="adjr2",type='l') # adj2에 대한 plot, xlab : x축이름, ylab : y축이름
points(which.max(reg.summary$adjr2),reg.summary$adjr2[which.max(reg.summary$adjr2)],col="red",cex=2,pch=20) # 최대 point에 붉은점
plot(reg.summary$bic,xlab="Number of Variables",ylab="bic",type='l') # bic에 대한 plot, xlab : x축이름, ylab : y축이름
points(which.min(reg.summary$bic),reg.summary$bic[which.min(reg.summary$bic)],col="blue",cex=2,pch=20) # 최소 point에 푸른점


## ----newregsubsetplot4-------------------------------------------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(regfit.full,scale="adjr2") # regsubset 의 summary를 adj2 기준으로 그린다.
plot(regfit.full,scale="bic") # regsubset 의 summary를 bic 기준으로 그린다.


## ----anova-------------------------------------------------------------------------------------------------------------------------------------
anova(lm(엔진출력~ 연료소비량+최대토크+양력+최고속도,data=ddd),lm(엔진출력~ 연료소비량+최대토크+양력+최고속도+총배기량,data=ddd))
# 분산분석


## ----newlm2------------------------------------------------------------------------------------------------------------------------------------
model<- lm(엔진출력~ 연료소비량+최대토크+양력+최고속도+총배기량,data=ddd) # linear model
summary(model) # 모형 적합의 summary


## ----newerror2---------------------------------------------------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(model),residuals(model),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(model),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(model),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----newerrortest2-----------------------------------------------------------------------------------------------------------------------------
gvlma(model) # 오차항의 기본가정 만족에 대한 검정 함수 gvlma

#####################################################
########4-2 모형 설명 ###
#####################################################


## ----finalmodel2-------------------------------------------------------------------------------------------------------------------------------
summary(model)$coefficients[,1] # 모델이 적합한 계수들


#####################################################
###### 5. 연료소비율을 반응변수로 하는 모형 #########
#####################################################

#####################################################
######## 5-1 선형 모형 적합 – 반응변수 : 연료소비율###
#####################################################


## ----outliercut3-------------------------------------------------------------------------------------------------------------------------------
dd2<-datana2[,c(-1,-4,-7)] # 다중공선성 제거를 위해 엔진출력 , 견인출력 , 총중량을 제거하여 dd2 에 저장
ddd2 <- dd2[-77,] # 이상치를 제거한 객체 ddd2 생성. 


## ----newregsubset3-----------------------------------------------------------------------------------------------------------------------------
regfit.full <- regsubsets(연료소비율~.,data = ddd2) # regsubset
reg.summary <- summary(regfit.full)
reg.summary


## ----newregsubsetplot5-------------------------------------------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(reg.summary$adjr2,xlab="Number of Variables",ylab="adjr2",type='l') # adj2에 대한 plot, xlab : x축이름, ylab : y축이름
points(which.max(reg.summary$adjr2),reg.summary$adjr2[which.max(reg.summary$adjr2)],col="red",cex=2,pch=20) # 최대 point에 붉은점
plot(reg.summary$bic,xlab="Number of Variables",ylab="bic",type='l') # bic에 대한 plot, xlab : x축이름, ylab : y축이름
points(which.min(reg.summary$bic),reg.summary$bic[which.min(reg.summary$bic)],col="blue",cex=2,pch=20) # 최소 point에 푸른점


## ----newregsubsetplot6-------------------------------------------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(regfit.full,scale="adjr2") # regsubset 의 summary를 adj2 기준으로 그린다.
plot(regfit.full,scale="bic") # regsubset 의 summary를 bic 기준으로 그린다.


## ----newlm3------------------------------------------------------------------------------------------------------------------------------------
model<- lm(연료소비율~ 최대토크+축간거리,data=ddd2) # linear model
summary(model) # 모형 적합의 summary


## ----newerror3---------------------------------------------------------------------------------------------------------------------------------
par(mfrow=c(1,2)) # plot을 1행 2열로 배치
plot(fitted(model),residuals(model),xlab= "fitted", ylab= "residuals") # fitted value와 잔차를 그림 xlab,ylab : 각 축의 이름
abline(h=0, col=2) # 수평선을 plot에 그림 . h=0 은 y축이 0인 선을 의미. col : 색지정, 2는 red
qqnorm(residuals(model),ylab="residuals",main= "") # 잔차의 normal 분포에 대한 quantile 그림, main : plot 제목
qqline(residuals(model),col=2) # quantile 그림이 완벽한 normal 일때의 선 


## ----newerrortest3-----------------------------------------------------------------------------------------------------------------------------
gvlma(model) # 오차항의 기본가정 만족에 대한 검정 함수 gvlma



#####################################################
######## 5-2 가법모형 ##############################
#####################################################

## ----gam---------------------------------------------------------------------------------------------------------------------------------------
model1 <- gam(연료소비율~s(엔진출력)+s(최대토크)+s(견인출력)+s(양력)+
                     s(유압출력)+s(총중량)+s(축간거리)+s(최고속도)+s(총배기량),data = datana2)
summary(model1)


## ----concurvity--------------------------------------------------------------------------------------------------------------------------------
concurvity(model1,full=T)  # 견인출력의 worst가 가장 크다.

model2 <- gam(연료소비율~s(엔진출력)+s(최대토크)+s(양력)+
                     s(유압출력)+s(총중량)+s(축간거리)+s(최고속도)+s(총배기량),data = datana2)
concurvity(model2,full=T)  # 총중량의 worst가 가장 크다.

model3 <- gam(연료소비율~s(엔진출력)+s(최대토크)+s(양력)+
                     s(유압출력)+s(축간거리)+s(최고속도)+s(총배기량),data = datana2)
concurvity(model3,full=T) # 엔진출력의 worst가 가장 크다.

model4 <- gam(연료소비율~s(최대토크)+s(양력)+
                     s(유압출력)+s(축간거리)+s(최고속도)+s(총배기량),data = datana2)
concurvity(model4,full=T) # 축간거리의 worst가 가장 크다.

model5 <- gam(연료소비율~s(최대토크)+s(양력)+
                     s(유압출력)+s(최고속도)+s(총배기량),data = datana2)
concurvity(model5,full=T) # 양력의 worst가 가장 크다.

model6 <- gam(연료소비율~s(최대토크)+
                     s(유압출력)+s(최고속도)+s(총배기량),data = datana2)
concurvity(model6,full=T) # 총배기량의 worst가 가장 크다.

model7 <- gam(연료소비율~s(최대토크)+
                     s(유압출력)+s(최고속도),data = datana2)
concurvity(model7,full=T) # 모든 변수의 worst가 적당하다.


## ----gamsummary--------------------------------------------------------------------------------------------------------------------------------
summary(model7) # 변수 선택 후의 gam model의  summary


## ----gamresi-----------------------------------------------------------------------------------------------------------------------------------
sort(abs(model7$residuals),decreasing = T)[1:5] # model의 residuals 절대값을 큰 순서대로 5개 정렬
which.max(model7$residuals) # residual 절대값이 최대인 관측치 번호


## ----finalf------------------------------------------------------------------------------------------------------------------------------------
modelf <- gam(연료소비율~s(최대토크)+
                     s(유압출력)+s(최고속도),data = datana2[-77,])
summary(modelf)


#####################################################
######## 5-3 모형 설명 ###
#####################################################

## ----fplot-------------------------------------------------------------------------------------------------------------------------------------
plot(modelf,ylab="f",page=1)

